import { useCallback, useEffect, useRef, useState } from 'react';
import type Phaser from 'phaser';
import { createGame } from './game/createGame';
import { minimapRect } from './game/map';

interface Hud {
  zone: string;
  tx: number;
  ty: number;
  zoom: number;
}

type Dir = 'up' | 'down' | 'left' | 'right';

function useViewport() {
  const [size, setSize] = useState({ w: window.innerWidth, h: window.innerHeight });
  useEffect(() => {
    const on = () => setSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);
  return size;
}

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const [hud, setHud] = useState<Hud>({ zone: 'Kenney City', tx: 0, ty: 0, zoom: 2 });
  const view = useViewport();
  const mini = minimapRect(view.w, view.h);

  useEffect(() => {
    if (!mount.current) return;
    const game = createGame(mount.current);
    gameRef.current = game;
    const onHud = (h: Hud) => setHud(h);
    game.events.on('hud', onHud);
    return () => {
      game.events.off('hud', onHud);
      game.destroy(true);
      gameRef.current = null;
    };
  }, []);

  const cmd = useCallback((name: string, payload?: unknown) => {
    gameRef.current?.events.emit(name, payload);
  }, []);

  // virtual D-pad ---------------------------------------------------------
  const held = useRef<Set<Dir>>(new Set());
  const pushPad = useCallback(() => {
    const s = held.current;
    cmd('cmd:pad', {
      x: (s.has('right') ? 1 : 0) - (s.has('left') ? 1 : 0),
      y: (s.has('down') ? 1 : 0) - (s.has('up') ? 1 : 0),
    });
  }, [cmd]);
  const press = (d: Dir) => () => {
    held.current.add(d);
    pushPad();
  };
  const release = (d: Dir) => () => {
    held.current.delete(d);
    pushPad();
  };

  const padBtn = (d: Dir, label: string, area: string) => (
    <button
      key={d}
      type="button"
      aria-label={`Move ${d}`}
      className={`px-btn px-pad ${area}`}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        press(d)();
      }}
      onPointerUp={release(d)}
      onPointerCancel={release(d)}
      onLostPointerCapture={release(d)}
      onContextMenu={(e) => e.preventDefault()}
    >
      {label}
    </button>
  );

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-[#0f3b33] select-none">
      <main
        ref={mount}
        aria-label="Interactive pixel-art city map"
        className="absolute inset-0 touch-none [&>canvas]:block [&>canvas]:h-full [&>canvas]:w-full"
      />

      <div className="pointer-events-none absolute inset-0 font-[Silkscreen,monospace] text-[#f6ecd0]">
        {/* Title + location ------------------------------------------------- */}
        <header
          className="px-rise px-panel absolute top-3 left-3 flex max-w-[calc(100vw-var(--mini-w)-2.5rem)] flex-col gap-2 p-3 sm:top-4 sm:left-4 sm:max-w-sm sm:p-4"
          style={{ ['--mini-w' as string]: `${mini.w}px` }}
        >
          <div className="flex items-center gap-2.5">
            <span aria-hidden className="px-logo" />
            <div className="min-w-0">
              <h1 className="px-title truncate text-[10px] leading-tight tracking-wide text-[#ffd84a] sm:text-xs">
                KENNEY CITY
              </h1>
              <p className="mt-1 truncate text-[10px] tracking-widest text-[#9fb0d8] uppercase sm:text-[11px]">
                RPG Big Map · Phaser 3
              </p>
            </div>
          </div>
          <div className="h-[3px] bg-[repeating-linear-gradient(90deg,#3a3760_0_6px,transparent_6px_10px)]" />
          <div className="flex items-center gap-2" aria-live="polite">
            <span aria-hidden className="px-pin" />
            <span key={hud.zone} className="px-zone truncate text-xs tracking-wide sm:text-sm">
              {hud.zone}
            </span>
          </div>
          <p className="text-[10px] tracking-widest text-[#9fb0d8] sm:text-[11px]">
            TILE {String(hud.tx).padStart(2, '0')},{String(hud.ty).padStart(2, '0')}
          </p>
        </header>

        {/* Minimap frame ---------------------------------------------------- */}
        <aside
          aria-label="Minimap"
          className="px-rise absolute"
          style={{ left: mini.x - 4, top: mini.y - 4, width: mini.w + 8, height: mini.h + 8, animationDelay: '120ms' }}
        >
          <div className="px-frame h-full w-full" />
          <span className="absolute -bottom-6 right-1 text-[10px] tracking-widest text-[#ffd84a]/90 drop-shadow-[0_2px_0_rgba(0,0,0,0.6)]">
            MAP · CLICK TO PAN
          </span>
        </aside>

        {/* Zoom / recenter -------------------------------------------------- */}
        <nav
          aria-label="Map controls"
          className="px-rise pointer-events-auto absolute right-3 bottom-4 flex flex-col items-center gap-2 sm:right-4 sm:bottom-5"
          style={{ animationDelay: '240ms' }}
        >
          <button type="button" className="px-btn" aria-label="Zoom in" onClick={() => cmd('cmd:zoom', 1)}>
            +
          </button>
          <span className="px-panel min-w-11 px-2 py-1 text-center text-[11px] tracking-wider text-[#ffd84a]" aria-live="polite">
            x{hud.zoom}
          </span>
          <button type="button" className="px-btn" aria-label="Zoom out" onClick={() => cmd('cmd:zoom', -1)}>
            −
          </button>
          <button type="button" className="px-btn px-btn-accent mt-1" aria-label="Recenter on hero" onClick={() => cmd('cmd:locate')}>
            <span aria-hidden className="px-target" />
          </button>
        </nav>

        {/* Keyboard hints (desktop) ----------------------------------------- */}
        <footer className="px-rise px-hint absolute bottom-4 left-4 hidden flex-col gap-2 sm:flex" style={{ animationDelay: '360ms' }}>
          <div className="px-panel flex items-center gap-3 px-3 py-2 text-[11px] tracking-wider">
            <span className="flex items-center gap-1.5">
              <kbd className="px-key">W</kbd>
              <kbd className="px-key">A</kbd>
              <kbd className="px-key">S</kbd>
              <kbd className="px-key">D</kbd>
              <span className="text-[#9fb0d8]">MOVE</span>
            </span>
            <span className="text-[#3a3760]">|</span>
            <span className="flex items-center gap-1.5">
              <kbd className="px-key px-key-wide">SHIFT</kbd>
              <span className="text-[#9fb0d8]">RUN</span>
            </span>
            <span className="text-[#3a3760]">|</span>
            <span className="text-[#9fb0d8]">CLICK TO WALK · WHEEL TO ZOOM · DRAG TO LOOK</span>
          </div>
          <p className="flex items-center gap-2 pl-1 text-[10px] tracking-widest text-[#f6ecd0]/70">
            <span className="rounded-full border-2 border-[#f6ecd0]/70 px-2 py-[1px] text-[9px]">CC0 1.0</span>
            Tile style inspired by Kenney · art drawn in code
          </p>
        </footer>

        {/* Touch D-pad ------------------------------------------------------ */}
        <div
          role="group"
          aria-label="Directional pad"
          className="px-dpad px-rise pointer-events-auto absolute bottom-5 left-4 touch-none"
          style={{ animationDelay: '360ms' }}
        >
          {padBtn('up', '▲', '[grid-area:u]')}
          {padBtn('left', '◀', '[grid-area:l]')}
          {padBtn('right', '▶', '[grid-area:r]')}
          {padBtn('down', '▼', '[grid-area:d]')}
        </div>
      </div>
    </div>
  );
}
