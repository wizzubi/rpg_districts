import Phaser from 'phaser';
import { rect, rng, disc, type Ctx } from './art';
import {
  COLS,
  CROSSWALKS,
  DOWNTOWN_X,
  HROADS,
  ROAD,
  ROWS,
  T,
  TILE,
  VROADS,
  WORLD_H,
  WORLD_W,
  inHRoad,
  inVRoad,
  type Grid,
} from './map';

const S = TILE;

const tileAt = (g: Grid, x: number, y: number, fallback: number) =>
  x < 0 || y < 0 || x >= COLS || y >= ROWS ? fallback : g[y][x];

/** Paint 1px lines on the sides of a tile where `pred(neighbour)` is true. */
function edges(c: Ctx, g: Grid, x: number, y: number, col: string, pred: (t: number) => boolean, self: number) {
  const px = x * S;
  const py = y * S;
  if (pred(tileAt(g, x, y - 1, self))) rect(c, col, px, py, S, 1);
  if (pred(tileAt(g, x, y + 1, self))) rect(c, col, px, py + S - 1, S, 1);
  if (pred(tileAt(g, x - 1, y, self))) rect(c, col, px, py, 1, S);
  if (pred(tileAt(g, x + 1, y, self))) rect(c, col, px + S - 1, py, 1, S);
}

function grass(c: Ctx, x: number, y: number) {
  const r = rng(x * 7919 + y * 104729 + 3);
  const px = x * S;
  const py = y * S;
  rect(c, '#1f9d78', px, py, S, S);
  for (let i = 0; i < 7; i++) {
    rect(c, r() < 0.5 ? '#27ab84' : '#198a69', px + Math.floor(r() * 14), py + Math.floor(r() * 16), 2, 1);
  }
  if (r() < 0.24) {
    const tx = px + 3 + Math.floor(r() * 9);
    const ty = py + 3 + Math.floor(r() * 9);
    rect(c, '#147a5a', tx, ty, 1, 3);
    rect(c, '#147a5a', tx + 2, ty + 1, 1, 2);
    rect(c, '#147a5a', tx - 2, ty + 1, 1, 2);
    rect(c, '#3cc79a', tx, ty, 1, 1);
  }
  if (r() < 0.045) {
    const cols = ['#f8f8f8', '#ffd84a', '#ff8fb0', '#9fd2ff'];
    const col = cols[Math.floor(r() * cols.length)];
    const fx = px + 2 + Math.floor(r() * 11);
    const fy = py + 2 + Math.floor(r() * 11);
    rect(c, col, fx, fy, 2, 2);
    rect(c, '#147a5a', fx, fy + 2, 1, 2);
  }
}

function asphalt(c: Ctx, x: number, y: number, dark: boolean) {
  const r = rng(x * 3571 + y * 9973 + 11);
  const px = x * S;
  const py = y * S;
  rect(c, dark ? '#282740' : '#6f6e7e', px, py, S, S);
  const alt = dark ? ['#302f4a', '#222138'] : ['#787788', '#666576'];
  for (let i = 0; i < 5; i++) rect(c, alt[Math.floor(r() * 2)], px + Math.floor(r() * 15), py + Math.floor(r() * 15), 1 + Math.floor(r() * 2), 1);
  if (r() < 0.05) {
    rect(c, dark ? '#1c1b30' : '#5a5968', px + 3, py + 5, 6, 1);
    rect(c, dark ? '#1c1b30' : '#5a5968', px + 8, py + 6, 3, 1);
  }
}

function sidewalk(c: Ctx, g: Grid, x: number, y: number) {
  const r = rng(x * 601 + y * 1307 + 5);
  const dt = x >= DOWNTOWN_X;
  const px = x * S;
  const py = y * S;
  const base = dt ? '#aaa8bd' : '#b9b9c5';
  const seam = dt ? '#9b99b0' : '#a9a9b8';
  const curb = dt ? '#cfcde2' : '#dadae6';
  rect(c, base, px, py, S, S);
  rect(c, seam, px + S - 1, py, 1, S);
  rect(c, seam, px, py + S - 1, S, 1);
  if (r() < 0.35) rect(c, seam, px + 3 + Math.floor(r() * 8), py + 3 + Math.floor(r() * 8), 2, 1);
  if (r() < 0.1) {
    rect(c, dt ? '#8f8da6' : '#9d9db0', px + 4, py + 4, 1, 3);
    rect(c, dt ? '#8f8da6' : '#9d9db0', px + 5, py + 6, 3, 1);
  }
  edges(c, g, x, y, curb, (t) => t === T.ROAD, T.SIDEWALK);
  edges(c, g, x, y, '#726f8a', (t) => t === T.GRASS || t === T.PATH || t === T.COBBLE || t === T.WATER, T.SIDEWALK);
}

function plaza(c: Ctx, g: Grid, x: number, y: number) {
  const r = rng(x * 431 + y * 887 + 9);
  const px = x * S;
  const py = y * S;
  rect(c, '#9d9bb3', px, py, S, S);
  rect(c, '#9290aa', px + S - 1, py, 1, S);
  rect(c, '#9290aa', px, py + S - 1, S, 1);
  if (r() < 0.3) rect(c, '#a8a6be', px + 2 + Math.floor(r() * 9), py + 2 + Math.floor(r() * 9), 3, 1);
  edges(c, g, x, y, '#b6b4ca', (t) => t === T.SIDEWALK, T.PLAZA);
}

function path(c: Ctx, g: Grid, x: number, y: number) {
  const r = rng(x * 211 + y * 733 + 21);
  const px = x * S;
  const py = y * S;
  rect(c, '#f4de92', px, py, S, S);
  for (let i = 0; i < 4; i++) rect(c, '#ecd07c', px + Math.floor(r() * 14), py + Math.floor(r() * 15), 2, 1);
  edges(c, g, x, y, '#d9b458', (t) => t !== T.PATH && t !== T.SIDEWALK && t !== T.PLAZA, T.PATH);
}

function cobble(c: Ctx, g: Grid, x: number, y: number) {
  const r = rng(x * 97 + y * 389 + 2);
  const px = x * S;
  const py = y * S;
  const cols = ['#c9744d', '#b5623f', '#a4573a', '#d88c60'];
  rect(c, '#7e3f2b', px, py, S, S);
  for (let j = 0; j < 4; j++) {
    const off = j % 2 ? 4 : 0;
    for (let i = -1; i < 3; i++) {
      const bx = px + i * 8 + off;
      const x0 = Math.max(bx, px);
      const x1 = Math.min(bx + 7, px + S);
      if (x1 > x0) rect(c, cols[Math.floor(r() * cols.length)], x0, py + j * 4, x1 - x0, 3);
    }
  }
  if (tileAt(g, x, y - 1, T.COBBLE) !== T.COBBLE) {
    rect(c, '#e8a878', px, py, S, 2);
  }
  if (tileAt(g, x, y + 1, T.COBBLE) !== T.COBBLE) {
    rect(c, '#5e2c1e', px, py + S - 2, S, 2);
  }
}

function water(c: Ctx, g: Grid, x: number, y: number) {
  const r = rng(x * 313 + y * 577 + 4);
  const px = x * S;
  const py = y * S;
  rect(c, '#3b8ed6', px, py, S, S);
  rect(c, '#348ad2', px, py + 8, S, 8);
  for (let i = 0; i < 3; i++) {
    const wx = px + Math.floor(r() * 10);
    const wy = py + 2 + Math.floor(r() * 12);
    rect(c, '#7cc4f4', wx, wy, 4, 1);
    rect(c, '#2a72b8', wx + 2, wy + 1, 3, 1);
  }
  edges(c, g, x, y, '#1f5fa8', (t) => t !== T.WATER, T.WATER);
  if (tileAt(g, x, y - 1, T.WATER) !== T.WATER) rect(c, '#6cb4ec', px + 1, py + 1, S - 2, 1);
}

function crosswalk(c: Ctx, x: number, y: number, w: number, h: number, bars: 'h' | 'v', dark: boolean) {
  const px = x * S;
  const py = y * S;
  const col = dark ? '#e6e6ee' : '#f2f2f8';
  const r = rng(x * 17 + y * 41);
  if (bars === 'h') {
    for (let yy = 3; yy < h * S - 3; yy += 6) {
      rect(c, col, px + 2, py + yy, w * S - 4, 3);
      if (r() < 0.4) rect(c, dark ? '#9a99ae' : '#a9a8bc', px + 2 + Math.floor(r() * 8), py + yy, 2, 1);
    }
  } else {
    for (let xx = 3; xx < w * S - 3; xx += 6) {
      rect(c, col, px + xx, py + 2, 3, h * S - 4);
      if (r() < 0.4) rect(c, dark ? '#9a99ae' : '#a9a8bc', px + xx, py + 2 + Math.floor(r() * 8), 1, 2);
    }
  }
}

function pIcon(c: Ctx, x: number, y: number) {
  rect(c, '#dfe6ff', x, y, 12, 12);
  rect(c, '#3a5fc0', x + 1, y + 1, 10, 10);
  const rows = ['1110', '1001', '1110', '1000', '1000'];
  rows.forEach((row, j) => {
    for (let i = 0; i < 4; i++) if (row[i] === '1') rect(c, '#ffffff', x + 4 + i, y + 3 + j, 1, 1);
  });
}

function bikeIcon(c: Ctx, x: number, y: number) {
  const col = '#b8b8cc';
  disc(c, col, x + 2, y + 6, 2);
  disc(c, col, x + 10, y + 6, 2);
  disc(c, '#6f6e7e', x + 2, y + 6, 1);
  disc(c, '#6f6e7e', x + 10, y + 6, 1);
  rect(c, col, x + 2, y + 5, 4, 1);
  rect(c, col, x + 5, y + 2, 1, 4);
  rect(c, col, x + 5, y + 2, 5, 1);
  rect(c, col, x + 9, y + 2, 1, 4);
  rect(c, col, x + 3, y + 1, 4, 1);
}

export function paintGround(scene: Phaser.Scene, g: Grid) {
  if (scene.textures.exists('ground')) scene.textures.remove('ground');
  const tex = scene.textures.createCanvas('ground', WORLD_W, WORLD_H);
  if (!tex) return;
  const c = tex.getContext();
  c.imageSmoothingEnabled = false;

  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      switch (g[y][x]) {
        case T.GRASS:
          grass(c, x, y);
          break;
        case T.ROAD:
          asphalt(c, x, y, x < DOWNTOWN_X);
          break;
        case T.SIDEWALK:
          sidewalk(c, g, x, y);
          break;
        case T.PLAZA:
          plaza(c, g, x, y);
          break;
        case T.PATH:
          path(c, g, x, y);
          break;
        case T.COBBLE:
          cobble(c, g, x, y);
          break;
        case T.WATER:
          water(c, g, x, y);
          break;
      }
    }
  }

  // lane markings ------------------------------------------------------
  const isCross = (x: number, y: number) => CROSSWALKS.some((k) => x >= k.x && x < k.x + k.w && y >= k.y && y < k.y + k.h);
  for (const h of HROADS) {
    const cy = (h + ROAD / 2) * S;
    for (let x = 0; x < COLS; x++) {
      if (inVRoad(x) || isCross(x, h)) continue;
      const px = x * S;
      if (x < DOWNTOWN_X) {
        rect(c, '#f2c230', px, cy - 2, S, 1);
        rect(c, '#f2c230', px, cy + 1, S, 1);
      } else {
        rect(c, '#e2e2ee', px, cy - 1, 9, 2);
      }
    }
  }
  for (const v of VROADS) {
    const cx = (v + ROAD / 2) * S;
    for (let y = 0; y < ROWS; y++) {
      if (inHRoad(y) || isCross(v, y)) continue;
      const py = y * S;
      if (v < DOWNTOWN_X) {
        rect(c, '#f2c230', cx - 2, py, 1, S);
        rect(c, '#f2c230', cx + 1, py, 1, S);
      } else {
        rect(c, '#e2e2ee', cx - 1, py, 2, 9);
      }
    }
  }
  // crosswalks
  for (const k of CROSSWALKS) crosswalk(c, k.x, k.y, k.w, k.h, k.bars, k.x < DOWNTOWN_X);

  // manholes
  const mh = (tx: number, ty: number) => {
    disc(c, '#1c1b30', tx * S + 8, ty * S + 8, 5);
    disc(c, '#34335a', tx * S + 8, ty * S + 8, 4);
    rect(c, '#1c1b30', tx * S + 4, ty * S + 8, 9, 1);
    rect(c, '#1c1b30', tx * S + 8, ty * S + 4, 1, 9);
  };
  for (const [x, y] of [[26, 12], [56, 10], [70, 31], [20, 50], [46, 20], [78, 40], [14, 3], [46, 56], [35, 31]]) mh(x, y);

  // bike lane icons on the east avenue
  for (const y of [16, 20, 24, 38, 42, 58]) bikeIcon(c, VROADS[2] * S + (y % 8 === 0 ? 42 : 10), y * S + 2);

  // parking lots on the east edge
  for (const [y0, y1] of [[15, 26], [35, 46]] as const) {
    const x0 = 81;
    const x1 = 89;
    rect(c, '#6f6e7e', x0 * S, y0 * S, (x1 - x0) * S, (y1 - y0) * S);
    for (let y = y0 * S; y < y1 * S; y += 2) for (let x = x0 * S; x < x1 * S; x += 3) if ((x + y) % 7 === 0) rect(c, '#787788', x, y, 1, 1);
    for (let x = x0 * S; x <= x1 * S; x += 32) {
      rect(c, '#e2e2ee', x, y0 * S, 1, 3 * S);
      rect(c, '#e2e2ee', x, (y1 - 3) * S, 1, 3 * S);
    }
    rect(c, '#e2e2ee', x0 * S, y0 * S, (x1 - x0) * S, 1);
    rect(c, '#e2e2ee', x0 * S, (y1 - 1) * S + 15, (x1 - x0) * S, 1);
    for (let x = x0 * S + 10; x < x1 * S - 12; x += 64) {
      pIcon(c, x, y0 * S + 18);
      pIcon(c, x + 32, (y1 - 3) * S + 18);
    }
  }

  tex.refresh();
}
