import Phaser from 'phaser';

/**
 * Procedural pixel-art generator. Every sprite is painted with 1px rectangles onto
 * an offscreen canvas, outlined, and registered as a Phaser texture.
 */
export type Ctx = CanvasRenderingContext2D;
export const PAD = 1;
export const OUT = '#1f1b2e';

export function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function rect(c: Ctx, col: string, x: number, y: number, w: number, h: number) {
  c.fillStyle = col;
  c.fillRect(x, y, w, h);
}

export function disc(c: Ctx, col: string, cx: number, cy: number, r: number) {
  if (r <= 0) return;
  c.fillStyle = col;
  for (let y = -r; y <= r; y++) {
    const w = Math.round(Math.sqrt(r * r - y * y + r * 0.5));
    c.fillRect(cx - w, cy + y, w * 2 + 1, 1);
  }
}

function hexToRgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function outlineCanvas(cv: HTMLCanvasElement, color: string) {
  const ctx = cv.getContext('2d');
  if (!ctx) return;
  const { width: w, height: h } = cv;
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  const [r, g, b] = hexToRgb(color);
  const solid = (x: number, y: number) => x >= 0 && y >= 0 && x < w && y < h && d[(y * w + x) * 4 + 3] > 140;
  const hits: number[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (d[(y * w + x) * 4 + 3] >= 20) continue;
      if (solid(x - 1, y) || solid(x + 1, y) || solid(x, y - 1) || solid(x, y + 1)) hits.push((y * w + x) * 4);
    }
  }
  for (const i of hits) {
    d[i] = r;
    d[i + 1] = g;
    d[i + 2] = b;
    d[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
}

export function make(
  scene: Phaser.Scene,
  key: string,
  w: number,
  h: number,
  draw: (c: Ctx) => void,
  outline: string | null = OUT,
) {
  if (scene.textures.exists(key)) scene.textures.remove(key);
  const tex = scene.textures.createCanvas(key, w + PAD * 2, h + PAD * 2);
  if (!tex) return;
  const c = tex.getContext();
  c.imageSmoothingEnabled = false;
  c.translate(PAD, PAD);
  draw(c);
  c.setTransform(1, 0, 0, 1, 0, 0);
  if (outline) outlineCanvas(tex.canvas, outline);
  tex.refresh();
}

/** Content size of a texture (without outline padding). */
export function sizeOf(scene: Phaser.Scene, key: string) {
  const f = scene.textures.getFrame(key);
  return { w: f.width - PAD * 2, h: f.height - PAD * 2 };
}

/* ------------------------------------------------------------------ */
/* Vegetation                                                          */
/* ------------------------------------------------------------------ */
interface LeafPal {
  dk: string;
  md: string;
  lt: string;
  hl: string;
}
const LEAF: LeafPal = { dk: '#17663c', md: '#2e9744', lt: '#62bf4e', hl: '#98da62' };
const LEAF_MINT: LeafPal = { dk: '#177a55', md: '#25a06c', lt: '#4cc78a', hl: '#86e3a8' };

function canopy(c: Ctx, cx: number, cy: number, rx: number, ry: number, n: number, seed: number, pal: LeafPal) {
  const r = rng(seed);
  const m = Math.min(rx, ry);
  const blobs: [number, number, number][] = [[cx, cy, Math.round(m * 0.78)]];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + r() * 0.5;
    const d = 0.5 + r() * 0.28;
    blobs.push([Math.round(cx + Math.cos(a) * rx * d), Math.round(cy + Math.sin(a) * ry * d), Math.round(m * (0.42 + r() * 0.16))]);
  }
  for (const [x, y, rad] of blobs) disc(c, pal.dk, x, y + 2, rad);
  for (const [x, y, rad] of blobs) disc(c, pal.md, x - 1, y - 1, rad - 1);
  for (const [x, y, rad] of blobs) disc(c, pal.lt, x - 2, y - 3, rad - 4);
  for (const [x, y, rad] of blobs) disc(c, pal.hl, x - 3, y - 5, rad - 8);
  for (let i = 0; i < n * 6; i++) {
    const b = blobs[Math.floor(r() * blobs.length)];
    const x = b[0] + Math.round((r() - 0.5) * b[2] * 1.0);
    const y = b[1] + Math.round((r() - 0.3) * b[2] * 0.9);
    rect(c, pal.dk, x, y, 2, 1);
    rect(c, pal.dk, x + 1, y + 1, 1, 1);
  }
}

function shadow(c: Ctx, cx: number, cy: number, rx: number, ry: number) {
  c.fillStyle = 'rgba(15,25,45,0.22)';
  for (let y = -ry; y <= ry; y++) {
    const w = Math.round(rx * Math.sqrt(1 - (y * y) / (ry * ry + 0.01)));
    c.fillRect(cx - w, cy + y, w * 2, 1);
  }
}

function drawTree(c: Ctx, w: number, h: number, seed: number, n: number, pal: LeafPal, trunkH: number) {
  const cx = Math.floor(w / 2);
  shadow(c, cx, h - 2, Math.round(w * 0.3), 3);
  rect(c, '#6b4226', cx - 3, h - trunkH - 2, 6, trunkH);
  rect(c, '#8f5e34', cx - 3, h - trunkH - 2, 2, trunkH);
  rect(c, '#46291a', cx + 2, h - trunkH - 2, 1, trunkH);
  rect(c, '#46291a', cx - 4, h - 4, 1, 2);
  rect(c, '#46291a', cx + 3, h - 4, 1, 2);
  const ch = h - trunkH + 4;
  canopy(c, cx, Math.round(ch / 2) + 1, Math.floor(w / 2) - 2, Math.floor(ch / 2) - 1, n, seed, pal);
}

function drawPalm(c: Ctx, w: number, h: number) {
  const cx = Math.floor(w / 2);
  shadow(c, cx, h - 2, 8, 3);
  const topY = 28;
  for (let y = h - 3; y >= topY; y--) {
    const x = cx - 2 + Math.round(Math.sin((h - y) / 15) * 2);
    rect(c, '#b98a4f', x, y, 4, 1);
    rect(c, '#8a5f33', x + 3, y, 1, 1);
    rect(c, '#e2b878', x, y, 1, 1);
    if ((h - y) % 4 === 0) rect(c, '#7a5029', x, y, 4, 1);
  }
  const tx = cx + Math.round(Math.sin((h - topY) / 15) * 2);
  const angles = [-175, -150, -122, -95, -62, -32, -5, 165, 20, 140];
  for (const deg of angles) {
    const a = (deg * Math.PI) / 180;
    const L = 17 + (Math.abs(deg) % 5);
    for (let t = 0; t <= L; t++) {
      const x = Math.round(tx + Math.cos(a) * t);
      const y = Math.round(topY + Math.sin(a) * t + (t * t) / (L * 1.3));
      rect(c, '#1b6b3a', x - 1, y - 1, 3, 3);
    }
    for (let t = 1; t <= L - 1; t++) {
      const x = Math.round(tx + Math.cos(a) * t);
      const y = Math.round(topY + Math.sin(a) * t + (t * t) / (L * 1.3));
      rect(c, t % 3 === 0 ? '#7fd05a' : '#37a34a', x, y - 1, 2, 2);
    }
  }
  rect(c, '#5a3418', tx - 2, topY + 1, 2, 2);
  rect(c, '#5a3418', tx + 1, topY + 2, 2, 2);
}

function drawConeTree(c: Ctx, w: number, h: number) {
  const cx = Math.floor(w / 2);
  for (let j = 0; j < h - 14; j++) {
    const half = Math.min(9, Math.round(1 + j * 0.3 - Math.floor(j / 12) * 0));
    const skirt = j % 13 < 2 ? 1 : 0;
    const hw = Math.min(10, half + skirt);
    rect(c, '#2bb8a0', cx - hw, 2 + j, hw * 2, 1);
    rect(c, '#1f8d7e', cx + Math.floor(hw / 3), 2 + j, Math.ceil((hw * 2) / 3), 1);
    rect(c, '#6fe0c8', cx - hw, 2 + j, 2, 1);
    if (j % 13 === 12) rect(c, '#167263', cx - hw, 2 + j, hw * 2, 1);
  }
  rect(c, '#b8a25e', 2, h - 14, w - 4, 14);
  rect(c, '#d8c88c', 3, h - 13, w - 6, 3);
  rect(c, '#8a7a44', 3, h - 3, w - 6, 2);
  rect(c, '#5a4a26', 2, h - 8, w - 4, 1);
}

/* ------------------------------------------------------------------ */
/* Props                                                               */
/* ------------------------------------------------------------------ */
function drawLamp(c: Ctx) {
  rect(c, '#3a3852', 3, 6, 2, 32);
  rect(c, '#2a283c', 1, 36, 6, 3);
  rect(c, '#3a3852', 3, 4, 8, 2);
  rect(c, '#2a283c', 9, 5, 5, 3);
  rect(c, '#f6eca4', 10, 8, 3, 1);
  rect(c, '#5a5878', 3, 6, 1, 30);
}

function drawTrafficLight(c: Ctx, state: 'red' | 'yellow' | 'green') {
  rect(c, '#3a3852', 3, 12, 2, 22);
  rect(c, '#2a283c', 1, 33, 6, 3);
  rect(c, '#1f1d2e', 0, 0, 8, 14);
  const off = '#3c3a4e';
  rect(c, state === 'red' ? '#ff4545' : off, 2, 1, 4, 3);
  rect(c, state === 'yellow' ? '#ffd23a' : off, 2, 5, 4, 3);
  rect(c, state === 'green' ? '#45f08a' : off, 2, 9, 4, 3);
}

function drawTrash(c: Ctx) {
  rect(c, '#8a889e', 1, 4, 9, 11);
  rect(c, '#a4a2b8', 1, 4, 2, 11);
  rect(c, '#6b6982', 8, 4, 2, 11);
  rect(c, '#6b6982', 0, 1, 11, 4);
  rect(c, '#8a889e', 1, 1, 9, 1);
  rect(c, '#5a5872', 3, 6, 1, 8);
  rect(c, '#5a5872', 6, 6, 1, 8);
}

function drawMailbox(c: Ctx) {
  rect(c, '#3a3852', 4, 10, 3, 7);
  rect(c, '#3b63d6', 0, 0, 11, 11);
  rect(c, '#5f88f0', 0, 0, 11, 2);
  rect(c, '#2444a0', 0, 9, 11, 2);
  rect(c, '#1a2a70', 2, 4, 7, 1);
}

function drawBench(c: Ctx) {
  rect(c, '#6b4226', 0, 0, 32, 4);
  rect(c, '#8f5e34', 0, 0, 32, 1);
  rect(c, '#a86f3e', 0, 5, 32, 3);
  rect(c, '#8f5e34', 0, 8, 32, 3);
  rect(c, '#3a2a20', 2, 11, 3, 4);
  rect(c, '#3a2a20', 27, 11, 3, 4);
}

function drawCone(c: Ctx) {
  rect(c, '#ff7a1a', 3, 0, 2, 2);
  rect(c, '#ff7a1a', 2, 2, 4, 6);
  rect(c, '#ffffff', 2, 4, 4, 1);
  rect(c, '#ffffff', 2, 6, 4, 1);
  rect(c, '#d85a00', 0, 8, 8, 2);
}

function drawBarricade(c: Ctx) {
  rect(c, '#555268', 2, 1, 2, 13);
  rect(c, '#555268', 22, 1, 2, 13);
  for (const y of [1, 6]) {
    rect(c, '#f4f4f8', 0, y, 26, 4);
    for (let x = 0; x < 26; x += 8) rect(c, '#e23a3a', x + 3, y, 4, 4);
  }
}

function drawStopSign(c: Ctx) {
  rect(c, '#3a3852', 4, 8, 2, 20);
  rect(c, '#d83030', 1, 1, 8, 8);
  rect(c, '#d83030', 3, 0, 4, 10);
  rect(c, '#d83030', 0, 3, 10, 4);
  rect(c, '#f4f4f8', 2, 4, 6, 2);
}

function drawBush(c: Ctx) {
  disc(c, '#17663c', 6, 6, 5);
  disc(c, '#2e9744', 5, 5, 4);
  disc(c, '#62bf4e', 4, 3, 2);
}

function drawRock(c: Ctx) {
  rect(c, '#8a8ea0', 1, 1, 5, 3);
  rect(c, '#b8bccc', 1, 1, 3, 1);
  rect(c, '#5f6378', 1, 4, 6, 1);
  rect(c, '#5f6378', 6, 2, 1, 2);
}

function drawFenceBack(c: Ctx, w: number, h: number) {
  const dk = '#0d5a45';
  rect(c, dk, 0, 0, w, 2);
  rect(c, dk, 0, 10, w, 2);
  for (let y = 2; y < 10; y++) for (let x = 0; x < w; x++) if ((x + y) % 3 === 0) rect(c, '#2fc596', x, y, 1, 1);
  for (const x of [0, w - 3]) {
    rect(c, dk, x, 0, 3, h);
    rect(c, '#1a8f6c', x + 1, 2, 1, h - 2);
  }
  for (let x = 24; x < w - 8; x += 24) {
    rect(c, dk, x, 0, 2, 12);
  }
}

function drawFenceFront(c: Ctx, w: number, gap: number) {
  const dk = '#0d5a45';
  const seg = (x0: number, x1: number) => {
    rect(c, dk, x0, 0, x1 - x0, 2);
    rect(c, dk, x0, 8, x1 - x0, 2);
    for (let y = 2; y < 8; y++) for (let x = x0; x < x1; x++) if ((x + y) % 3 === 0) rect(c, '#2fc596', x, y, 1, 1);
    rect(c, dk, x0, 0, 3, 12);
    rect(c, dk, x1 - 3, 0, 3, 12);
    rect(c, '#1a8f6c', x0 + 1, 2, 1, 9);
  };
  seg(0, gap);
  seg(gap + 16, w);
}

/* ------------------------------------------------------------------ */
/* Buildings                                                           */
/* ------------------------------------------------------------------ */
function win(c: Ctx, x: number, y: number, w: number, h: number, frame = '#22357f') {
  rect(c, frame, x, y, w, h);
  rect(c, '#3f74e6', x + 1, y + 1, w - 2, h - 2);
  rect(c, '#2c58c4', x + 1, y + h - 3, w - 2, 2);
  rect(c, '#78a6ff', x + 1, y + 1, w - 2, 1);
  for (let i = 0; i < h - 4; i++) {
    const sx = x + w - 3 - i;
    if (sx > x) rect(c, '#9cc2ff', sx, y + 1 + i, 1, 1);
    if (sx - 3 > x) rect(c, '#9cc2ff', sx - 3, y + 1 + i, 1, 1);
  }
  rect(c, '#d9dbe8', x - 1, y + h, w + 2, 1);
}

function acUnit(c: Ctx, x: number, y: number) {
  rect(c, '#9a98b2', x, y + 1, 18, 10);
  rect(c, '#e8e8f2', x, y, 18, 9);
  rect(c, '#ffffff', x, y, 18, 1);
  rect(c, '#b4b2c8', x, y + 9, 18, 1);
  for (const dx of [5, 13]) {
    disc(c, '#8a88a4', x + dx, y + 4, 2);
    rect(c, '#3e3c58', x + dx, y + 4, 1, 1);
  }
}

function octFill(c: Ctx, col: string, x: number, y: number, w: number, h: number, ct: number, cb: number, hatch?: string) {
  for (let j = 0; j < h; j++) {
    const inset = Math.max(0, ct - j, cb - (h - 1 - j));
    const x0 = x + inset;
    const ww = w - inset * 2;
    if (ww <= 0) continue;
    rect(c, col, x0, y + j, ww, 1);
    if (hatch) {
      c.fillStyle = hatch;
      for (let i = 0; i < ww; i++) if ((x0 + i + y + j) % 4 === 0) c.fillRect(x0 + i, y + j, 1, 1);
    }
  }
}

function brickFill(c: Ctx, x: number, y: number, w: number, h: number, base: string, mortar: string, seed: number) {
  const r = rng(seed);
  rect(c, base, x, y, w, h);
  for (let j = 0; j < h; j += 4) {
    rect(c, mortar, x, y + j + 3, w, 1);
    const off = (j / 4) % 2 ? 4 : 0;
    for (let i = off; i < w; i += 8) rect(c, mortar, x + i, y + j, 1, 3);
    if (r() < 0.6) rect(c, 'rgba(255,255,255,0.10)', x + Math.floor(r() * w), y + j, 3, 1);
  }
}

interface BoxCfg {
  w: number;
  roofH: number;
  wallH: number;
  ct: number;
  cb: number;
  roof: string;
  hatch: string;
  edge: string;
  trim: string;
  trimHi: string;
  wall: string;
  wallDk: string;
  brick?: string;
  cols: number;
  rows: number;
  doorW: number;
  doorCol: string;
  awning: string;
  ac: [number, number][];
  side?: number;
  sideCol?: string;
  winInset?: number;
}

function drawBox(c: Ctx, k: BoxCfg) {
  const side = k.side ?? 0;
  const rw = k.w - side;
  const total = k.roofH + k.wallH;
  const ty = k.roofH - k.cb;

  if (side) {
    // right-hand side face
    const sy = Math.round(k.roofH * 0.42);
    rect(c, k.sideCol ?? k.wallDk, rw, sy, side, total - sy);
    rect(c, k.edge, rw, sy, side, 3);
    rect(c, k.trim, rw, ty, side, 5);
    const rows = k.rows;
    const y0 = ty + 9;
    const rowH = (k.wallH - 14) / rows;
    for (let r = 0; r < rows; r++) {
      const wy = Math.round(y0 + rowH * r + rowH * 0.22);
      rect(c, '#22357f', rw + 3, wy, side - 6, Math.round(rowH * 0.5));
      rect(c, '#3f74e6', rw + 4, wy + 1, side - 8, Math.round(rowH * 0.5) - 2);
    }
  }

  octFill(c, k.edge, 0, 0, rw, k.roofH, k.ct, k.cb);
  octFill(c, k.roof, 2, 2, rw - 4, k.roofH - 5, Math.max(0, k.ct - 2), Math.max(0, k.cb - 2), k.hatch);
  rect(c, 'rgba(255,255,255,0.35)', 2 + k.ct, 1, rw - 4 - k.ct * 2, 1);
  for (const [x, y] of k.ac) acUnit(c, x, y);

  // trim band
  rect(c, k.trim, 0, ty, rw, 5);
  rect(c, k.trimHi, 0, ty, rw, 1);
  rect(c, 'rgba(0,0,0,0.25)', 0, ty + 4, rw, 1);

  // wall
  const wy = ty + 5;
  if (k.brick) brickFill(c, 0, wy, rw, total - wy, k.wall, k.brick, rw * 7 + total);
  else rect(c, k.wall, 0, wy, rw, total - wy);
  rect(c, k.wallDk, 0, wy, rw, 2);
  rect(c, k.wallDk, 0, total - 2, rw, 2);
  rect(c, 'rgba(0,0,0,0.12)', rw - 2, wy, 2, total - wy);

  // windows
  const mx = k.winInset ?? 6;
  const availW = rw - mx * 2;
  const cw = availW / k.cols;
  const ww = Math.max(6, Math.round(cw * 0.52));
  const y0 = wy + 5;
  const rowH = (total - wy - 8) / k.rows;
  const wh = Math.max(6, Math.round(rowH * 0.52));
  for (let r = 0; r < k.rows; r++) {
    for (let col = 0; col < k.cols; col++) {
      const x = Math.round(mx + cw * col + (cw - ww) / 2);
      const y = Math.round(y0 + rowH * r + (rowH - wh) / 2);
      const lastRow = r === k.rows - 1;
      if (lastRow && k.doorW && Math.abs(x + ww / 2 - rw / 2) < k.doorW / 2 + 6) continue;
      win(c, x, y, ww, wh);
    }
    if (!k.brick && r < k.rows - 1) rect(c, 'rgba(120,124,150,0.35)', 0, Math.round(y0 + rowH * (r + 1) - 2), rw, 1);
  }

  // door
  if (k.doorW) {
    const dx = Math.round((rw - k.doorW) / 2);
    const dy = total - 17;
    rect(c, k.awning, dx - 3, dy - 4, k.doorW + 6, 4);
    rect(c, 'rgba(255,255,255,0.35)', dx - 3, dy - 4, k.doorW + 6, 1);
    rect(c, '#1f1b2e', dx, dy, k.doorW, 17);
    rect(c, k.doorCol, dx + 1, dy + 1, k.doorW - 2, 16);
    rect(c, '#9cc2ff', dx + 2, dy + 2, 2, 12);
    rect(c, '#1f1b2e', dx + Math.floor(k.doorW / 2), dy + 1, 1, 16);
  }
}

interface RoofPal {
  base: string;
  light: string;
  hi: string;
  dark: string;
}
const ROOF_RED: RoofPal = { base: '#c8483f', light: '#e0665a', hi: '#f39680', dark: '#8e2c31' };
const ROOF_BLUE: RoofPal = { base: '#3f80e2', light: '#68a3f6', hi: '#9cc8ff', dark: '#2653ad' };
const ROOF_ORANGE: RoofPal = { base: '#d5604b', light: '#ea7f62', hi: '#f8a684', dark: '#9c3a34' };

function drawHouse(c: Ctx, w: number, pal: RoofPal, wall: string, wallDk: string, dbl: boolean) {
  const roofH = 34;
  const total = 58;
  // wall
  rect(c, wall, 3, roofH - 4, w - 6, total - roofH + 4);
  rect(c, wallDk, 3, roofH - 4, w - 6, 5);
  rect(c, 'rgba(0,0,0,0.12)', w - 6, roofH, 3, total - roofH);
  rect(c, 'rgba(0,0,0,0.18)', 3, total - 2, w - 6, 2);
  // roof
  rect(c, pal.dark, 0, 0, w, roofH);
  rect(c, pal.base, 1, 1, w - 2, roofH - 3);
  for (let y = 7; y < roofH - 3; y += 4) {
    rect(c, pal.dark, 1, y, w - 2, 1);
    const off = ((y - 3) / 4) % 2 ? 4 : 0;
    for (let x = 1 + off; x < w - 1; x += 8) rect(c, pal.dark, x, y - 3, 1, 3);
    rect(c, pal.light, 1, y + 1, w - 2, 1);
  }
  rect(c, pal.light, 1, 1, w - 2, 4);
  rect(c, pal.hi, 1, 1, w - 2, 1);
  rect(c, pal.dark, 0, roofH - 2, w, 2);
  rect(c, 'rgba(0,0,0,0.25)', 0, roofH, w, 2);
  // openings
  const wy = roofH + 5;
  win(c, 8, wy, 14, 11, '#e8e8f4');
  rect(c, '#3f74e6', 9, wy + 1, 12, 9);
  if (dbl) {
    win(c, w - 24, wy, 14, 11, '#e8e8f4');
    rect(c, '#3f74e6', w - 23, wy + 1, 12, 9);
    const dx = Math.floor(w / 2) - 9;
    rect(c, '#1f1b2e', dx, total - 17, 18, 17);
    rect(c, '#8a5330', dx + 1, total - 16, 8, 16);
    rect(c, '#8a5330', dx + 9, total - 16, 8, 16);
    rect(c, '#b57443', dx + 2, total - 15, 2, 12);
    rect(c, '#b57443', dx + 10, total - 15, 2, 12);
  } else {
    const dx = Math.floor(w * 0.6);
    rect(c, '#1f1b2e', dx, total - 17, 12, 17);
    rect(c, '#8a5330', dx + 1, total - 16, 10, 16);
    rect(c, '#b57443', dx + 2, total - 15, 3, 12);
    rect(c, '#f0d060', dx + 8, total - 9, 1, 2);
  }
}

function drawShop(c: Ctx, w: number) {
  const roofH = 56;
  const total = 108;
  rect(c, '#8b7a45', 0, 0, w, roofH);
  rect(c, '#dcc88e', 1, 1, w - 2, roofH - 2);
  rect(c, '#f0e2b0', 1, 1, w - 2, 2);
  rect(c, '#6c6985', 4, 4, w - 8, 44);
  rect(c, '#c4c1d8', 5, 5, w - 10, 42);
  for (let y = 5; y < 47; y++) for (let x = 5; x < w - 5; x++) if ((x + y) % 5 === 0) rect(c, '#b0adc6', x, y, 1, 1);
  acUnit(c, w - 44, 14);
  rect(c, '#e8e8f2', 16, 14, 20, 12);
  rect(c, '#8a88a4', 16, 25, 20, 1);
  rect(c, '#3e3c58', 20, 18, 12, 2);
  rect(c, '#b89a5a', 0, roofH - 6, w, 6);
  rect(c, '#f0e2b0', 0, roofH - 6, w, 1);
  // facade
  brickFill(c, 0, roofH, w, total - roofH, '#b5453b', '#7e2a2c', 991);
  rect(c, '#f0e2b0', 0, roofH, w, 4);
  rect(c, '#b89a5a', 0, roofH + 4, w, 1);
  for (const x of [0, w - 12]) {
    rect(c, '#e8dcb0', x, roofH, 12, total - roofH);
    rect(c, '#c8b880', x + 10, roofH, 2, total - roofH);
    rect(c, '#fff6d0', x, roofH, 1, total - roofH);
  }
  const shopWin = (x: number) => {
    rect(c, '#e8dcb0', x, 66, 20, 26);
    rect(c, '#2f6b58', x + 2, 68, 16, 20);
    rect(c, '#7ec0a8', x + 3, 69, 14, 18);
    rect(c, '#bfe8d4', x + 3, 69, 14, 2);
    for (let i = 0; i < 10; i++) rect(c, '#a4dcc4', x + 14 - i, 71 + i, 1, 1);
    rect(c, '#c8b880', x, 92, 20, 3);
    rect(c, '#8a2a2c', x - 1, 95, 22, 2);
  };
  shopWin(14);
  shopWin(38);
  shopWin(w - 34);
  shopWin(w - 58);
  const dx = Math.floor(w / 2) - 12;
  rect(c, '#e8dcb0', dx - 3, 64, 30, 44);
  rect(c, '#1f1b2e', dx, 72, 24, 36);
  rect(c, '#bfe8f0', dx + 1, 73, 11, 35);
  rect(c, '#bfe8f0', dx + 13, 73, 10, 35);
  rect(c, '#8fc8dc', dx + 1, 73, 22, 3);
  rect(c, '#e8f8ff', dx + 3, 78, 2, 14);
  rect(c, '#e8f8ff', dx + 15, 78, 2, 14);
  rect(c, '#3e8a6a', dx - 3, 64, 30, 6);
  rect(c, '#5ec08c', dx - 3, 64, 30, 2);
}

function drawMall(c: Ctx, w: number) {
  const total = 116;
  const roofH = 68;
  rect(c, '#54516e', 0, 0, w, roofH);
  rect(c, '#d9cfa2', 2, 2, w - 4, roofH - 2);
  rect(c, '#efe6be', 2, 2, w - 4, 2);
  rect(c, '#b8ad80', 2, roofH - 4, w - 4, 4);
  // brick courtyard
  const bx = Math.floor(w * 0.22);
  const bw = Math.floor(w * 0.56);
  brickFill(c, bx, 8, bw, roofH - 12, '#b8683a', '#8a4a2a', 4242);
  rect(c, '#7a4a30', bx - 2, 6, bw + 4, 2);
  rect(c, '#7a4a30', bx - 2, 6, 2, roofH - 10);
  rect(c, '#7a4a30', bx + bw, 6, 2, roofH - 10);
  // glass tower slab
  const tx = Math.floor(w / 2) - 8;
  rect(c, '#5c5a78', tx - 1, 0, 18, roofH - 2);
  rect(c, '#e8eef6', tx, 1, 16, roofH - 4);
  rect(c, '#b8d0e8', tx + 3, 4, 3, roofH - 10);
  rect(c, '#b8d0e8', tx + 10, 4, 3, roofH - 10);
  rect(c, '#ffffff', tx + 1, 1, 14, 1);
  // side rooftop boxes
  acUnit(c, 12, 14);
  acUnit(c, w - 30, 30);
  // lower storefront
  brickFill(c, 0, roofH, w, 10, '#c4703c', '#8a4a2a', 777);
  rect(c, '#54516e', 0, roofH, w, 2);
  const ay = roofH + 10;
  for (let x = 0; x < w; x += 12) {
    rect(c, x % 24 === 0 ? '#2b7a4c' : '#48ab6e', x, ay, 12, 10);
    rect(c, 'rgba(0,0,0,0.2)', x, ay + 8, 12, 2);
  }
  rect(c, '#1e5a38', 0, ay + 10, w, 1);
  const gy = ay + 11;
  rect(c, '#dff4f0', 0, gy, w, total - gy);
  for (let x = 0; x < w; x += 26) {
    rect(c, '#88bdb4', x, gy, 2, total - gy);
    rect(c, '#f8ffff', x + 3, gy + 3, 2, 10);
  }
  rect(c, '#88bdb4', 0, gy, w, 2);
  rect(c, '#54516e', 0, total - 2, w, 2);
  const dx = Math.floor(w / 2) - 10;
  rect(c, '#2f8a5c', dx - 2, gy, 24, total - gy);
  rect(c, '#bfe8f0', dx, gy + 2, 9, total - gy - 3);
  rect(c, '#bfe8f0', dx + 11, gy + 2, 9, total - gy - 3);
}

function drawWarehouse(c: Ctx, w: number) {
  const roofH = 66;
  const total = 100;
  rect(c, '#54516e', 0, 0, w, roofH);
  rect(c, '#a4a2b8', 2, 2, w - 4, roofH - 4);
  for (let y = 2; y < roofH - 2; y++) for (let x = 2; x < w - 2; x++) if ((x + y) % 4 === 0) rect(c, '#b6b4c8', x, y, 1, 1);
  for (const [x, y] of [
    [0, 0],
    [w - 26, 0],
  ]) {
    rect(c, '#6a6248', x, y, 26, 26);
    rect(c, '#e0d6a8', x + 1, y + 1, 24, 24);
    rect(c, '#f4ecc4', x + 1, y + 1, 24, 2);
    rect(c, '#c4b884', x + 1, y + 22, 24, 3);
  }
  // roof hatch + signs
  rect(c, '#6a6a82', 44, 20, 22, 20);
  rect(c, '#dcdce8', 45, 21, 20, 18);
  rect(c, '#8a88a4', 52, 26, 6, 8);
  acUnit(c, w - 70, 34);
  rect(c, '#c4b884', 0, roofH - 5, w, 5);
  rect(c, '#6a6248', 0, roofH - 5, w, 1);
  // facade
  brickFill(c, 0, roofH, w, total - roofH, '#c7683b', '#8a4526', 1717);
  for (let x = 0; x < w; x += 44) {
    rect(c, '#e0d6a8', x, roofH, 8, total - roofH);
    rect(c, '#c4b884', x + 6, roofH, 2, total - roofH);
  }
  rect(c, '#e0d6a8', w - 8, roofH, 8, total - roofH);
  for (let x = 14; x < w - 20; x += 44) {
    rect(c, '#1f1b2e', x, roofH + 8, 26, 16);
    rect(c, '#2c3f7c', x + 1, roofH + 9, 24, 14);
    rect(c, '#4c78d8', x + 1, roofH + 9, 24, 2);
    for (let i = 0; i < 12; i++) rect(c, '#7aa4f4', x + 20 - i, roofH + 11 + i, 1, 1);
  }
}

function drawApartment(c: Ctx, w: number) {
  const roofH = 46;
  const total = 106;
  rect(c, '#6a6248', 0, 0, w, roofH);
  rect(c, '#dcd2a4', 1, 1, w - 2, roofH - 1);
  rect(c, '#f2e8c0', 1, 1, w - 2, 2);
  rect(c, '#54516e', 6, 6, w - 12, roofH - 14);
  rect(c, '#a4a2b8', 7, 7, w - 14, roofH - 16);
  for (let y = 7; y < roofH - 9; y++) for (let x = 7; x < w - 7; x++) if ((x + y) % 4 === 0) rect(c, '#b6b4c8', x, y, 1, 1);
  rect(c, '#e0d6a8', Math.floor(w / 2) - 14, 14, 28, 14);
  rect(c, '#54516e', Math.floor(w / 2) - 14, 14, 28, 1);
  rect(c, '#54516e', Math.floor(w / 2) - 11, 26, 22, 1);
  rect(c, '#c4b884', 1, roofH - 6, w - 2, 6);
  // wall
  rect(c, '#e8e0c0', 0, roofH, w, total - roofH);
  rect(c, '#c4b884', 0, roofH, w, 3);
  for (const x of [0, w - 34]) {
    brickFill(c, x, roofH + 3, 34, total - roofH - 3, '#c8683c', '#8a4526', x + 31);
    rect(c, '#e0d6a8', x + (x === 0 ? 32 : 0), roofH + 3, 2, total - roofH - 3);
    win(c, x + 6, roofH + 10, 10, 14, '#f0e8c8');
    win(c, x + 18, roofH + 10, 10, 14, '#f0e8c8');
    win(c, x + 6, roofH + 34, 10, 14, '#f0e8c8');
    win(c, x + 18, roofH + 34, 10, 14, '#f0e8c8');
  }
  const mx = Math.floor(w / 2);
  rect(c, '#54516e', mx - 20, roofH + 6, 40, 18);
  win(c, mx - 17, roofH + 9, 14, 12, '#e8e8f4');
  win(c, mx + 3, roofH + 9, 14, 12, '#e8e8f4');
  rect(c, '#7a7890', mx - 20, total - 34, 40, 8);
  rect(c, '#1f1b2e', mx - 14, total - 26, 28, 26);
  rect(c, '#bfe0f0', mx - 13, total - 25, 12, 25);
  rect(c, '#bfe0f0', mx + 1, total - 25, 12, 25);
  rect(c, '#e8f8ff', mx - 10, total - 20, 2, 10);
  rect(c, '#e8f8ff', mx + 4, total - 20, 2, 10);
  rect(c, '#54516e', 0, total - 2, w, 2);
}

/* ------------------------------------------------------------------ */
/* Vehicles                                                            */
/* ------------------------------------------------------------------ */
interface CarCol {
  b: string;
  d: string;
  l: string;
}
export const CAR_COLORS: Record<string, CarCol> = {
  red: { b: '#d84040', d: '#98262c', l: '#ec6e66' },
  blue: { b: '#3d6fd8', d: '#254499', l: '#6b96f0' },
  green: { b: '#3f9a52', d: '#276a37', l: '#66bd78' },
  orange: { b: '#f2a622', d: '#b6700f', l: '#ffc85a' },
  gray: { b: '#8c8ca0', d: '#5d5d74', l: '#b4b4c8' },
  teal: { b: '#2fb0a0', d: '#1d7a70', l: '#5ed8c8' },
};
export const VEHICLES: { kind: 'car' | 'van' | 'taxi'; color: string }[] = [
  { kind: 'car', color: 'red' },
  { kind: 'car', color: 'blue' },
  { kind: 'taxi', color: 'orange' },
  { kind: 'van', color: 'green' },
  { kind: 'car', color: 'gray' },
  { kind: 'van', color: 'blue' },
  { kind: 'car', color: 'teal' },
  { kind: 'taxi', color: 'orange' },
];
export const vehicleKey = (kind: string, color: string, o: 'h' | 'v') => `${kind}_${color}_${o}`;

function drawVehicleH(c: Ctx, kind: string, col: CarCol, w: number, h: number) {
  const wheel = '#1c1a28';
  for (const x of [5, w - 14]) {
    rect(c, wheel, x, 0, 9, 3);
    rect(c, wheel, x, h - 3, 9, 3);
  }
  rect(c, col.d, 1, 2, w - 2, h - 4);
  rect(c, col.b, 1, 2, w - 2, h - 7);
  c.clearRect(1, 2, 1, 1);
  c.clearRect(w - 2, 2, 1, 1);
  c.clearRect(1, h - 3, 1, 1);
  c.clearRect(w - 2, h - 3, 1, 1);
  const rx = kind === 'van' ? 4 : 11;
  const rw = kind === 'van' ? w - 14 : w - 24;
  rect(c, col.l, rx, 4, rw, h - 9);
  rect(c, col.b, rx, h - 7, rw, 1);
  rect(c, '#a8dcff', rx + rw, 4, 4, h - 9);
  rect(c, '#e4f6ff', rx + rw, 4, 1, h - 9);
  rect(c, '#7fb8e0', rx - 3, 5, 3, h - 11);
  rect(c, '#fff3a0', w - 2, 3, 1, 3);
  rect(c, '#fff3a0', w - 2, h - 6, 1, 3);
  rect(c, '#ff4a4a', 1, 3, 1, 3);
  rect(c, '#ff4a4a', 1, h - 6, 1, 3);
  if (kind === 'taxi') {
    rect(c, '#ffffff', rx + Math.floor(rw / 2) - 3, Math.floor(h / 2) - 3, 6, 5);
    rect(c, '#222', rx + Math.floor(rw / 2) - 3, Math.floor(h / 2) - 1, 2, 1);
    for (let x = 2; x < w - 4; x += 4) rect(c, x % 8 === 2 ? '#1f1b2e' : '#ffffff', x, h - 6, 2, 1);
  }
}

/* ------------------------------------------------------------------ */
/* Characters                                                          */
/* ------------------------------------------------------------------ */
interface PersonPal {
  skin: string;
  hair: string;
  shirt: string;
  shirtDk: string;
  pants: string;
}
export const PEOPLE: PersonPal[] = [
  { skin: '#f2b892', hair: '#7a3b1e', shirt: '#d8423a', shirtDk: '#a02a2c', pants: '#3a4a8a' },
  { skin: '#c98a5e', hair: '#2a1a12', shirt: '#3a6ad8', shirtDk: '#264aa0', pants: '#2d2d3a' },
  { skin: '#f2c7a2', hair: '#e0a030', shirt: '#3fa35a', shirtDk: '#287a3e', pants: '#5a4a3a' },
  { skin: '#e0a070', hair: '#5a2a10', shirt: '#f0c030', shirtDk: '#b8901a', pants: '#3a3a6a' },
  { skin: '#f2b892', hair: '#c05030', shirt: '#e0607a', shirtDk: '#a8405a', pants: '#403858' },
  { skin: '#8a5a3a', hair: '#1a1010', shirt: '#f4f4f8', shirtDk: '#b8bccc', pants: '#3a6a8a' },
  // hero
  { skin: '#f6c39c', hair: '#3a2418', shirt: '#ff7a2e', shirtDk: '#c2531a', pants: '#25336e' },
];
export const HERO = PEOPLE.length - 1;

function drawPerson(c: Ctx, p: PersonPal, dir: 'down' | 'up' | 'side', f: number, hero: boolean) {
  const legTop = 11;
  const shoes = '#2a2030';
  if (dir === 'side') {
    const a = f === 1 ? -2 : f === 2 ? 2 : 0;
    rect(c, p.pants, 3 + a, legTop, 3, 4);
    rect(c, shoes, 3 + a, 15, 4, 1);
    rect(c, p.pants, 5 - a, legTop, 3, 4);
    rect(c, shoes, 5 - a, 15, 4, 1);
    rect(c, p.shirt, 3, 6, 5, 6);
    rect(c, p.shirtDk, 3, 6, 1, 6);
    rect(c, p.shirtDk, 4 - a / 2, 7, 3, 4);
    rect(c, p.skin, 4 - a / 2, 10, 3, 1);
    rect(c, p.skin, 3, 1, 5, 5);
    rect(c, p.hair, 2, 0, 6, 3);
    rect(c, p.hair, 2, 3, 2, 3);
    rect(c, '#2a2030', 7, 4, 1, 1);
    if (hero) rect(c, '#e8e8f0', 6, 0, 2, 1);
  } else {
    const l = f === 1 ? 1 : 0;
    const r = f === 2 ? 1 : 0;
    rect(c, p.pants, 2, legTop - l * 0, 3, 4 - l);
    rect(c, shoes, 2, 15 - l, 3, 1);
    rect(c, p.pants, 5, legTop, 3, 4 - r);
    rect(c, shoes, 5, 15 - r, 3, 1);
    rect(c, p.shirt, 1, 6, 8, 6);
    rect(c, p.shirtDk, 1, 6, 1, 6);
    rect(c, p.shirtDk, 8, 6, 1, 6);
    rect(c, p.skin, 0, 10 + (f === 1 ? 1 : 0), 1, 2);
    rect(c, p.skin, 9, 10 + (f === 2 ? 1 : 0), 1, 2);
    rect(c, p.shirt, 0, 7, 1, 3);
    rect(c, p.shirt, 9, 7, 1, 3);
    rect(c, p.skin, 2, 1, 6, 5);
    if (dir === 'down') {
      rect(c, p.hair, 2, 0, 6, 2);
      rect(c, p.hair, 2, 2, 1, 1);
      rect(c, p.hair, 7, 2, 1, 1);
      rect(c, '#2a2030', 3, 4, 1, 1);
      rect(c, '#2a2030', 6, 4, 1, 1);
    } else {
      rect(c, p.hair, 2, 0, 6, 5);
      rect(c, p.skin, 3, 5, 4, 1);
    }
    if (hero) rect(c, '#e8e8f0', 2, 0, 6, 1);
  }
}

/* ------------------------------------------------------------------ */
/* Public: build every texture                                         */
/* ------------------------------------------------------------------ */
export function buildTextures(scene: Phaser.Scene) {
  // vegetation
  make(scene, 'treeBig', 56, 76, (c) => drawTree(c, 56, 76, 11, 8, LEAF, 14));
  make(scene, 'treeBig2', 52, 72, (c) => drawTree(c, 52, 72, 29, 7, LEAF_MINT, 14));
  make(scene, 'treeMid', 40, 54, (c) => drawTree(c, 40, 54, 5, 6, LEAF, 10));
  make(scene, 'treeSmall', 26, 36, (c) => drawTree(c, 26, 36, 21, 5, LEAF, 8));
  make(scene, 'palm', 40, 76, (c) => drawPalm(c, 40, 76));
  make(scene, 'coneTree', 24, 54, (c) => drawConeTree(c, 24, 54));
  make(scene, 'bush', 12, 11, drawBush);
  make(scene, 'rock', 8, 6, drawRock);

  // props
  make(scene, 'lamp', 15, 40, drawLamp);
  for (const s of ['red', 'yellow', 'green'] as const) make(scene, `tl_${s}`, 8, 36, (c) => drawTrafficLight(c, s));
  make(scene, 'trash', 11, 15, drawTrash);
  make(scene, 'mailbox', 11, 17, drawMailbox);
  make(scene, 'bench', 32, 15, drawBench);
  make(scene, 'cone', 8, 10, drawCone);
  make(scene, 'barricade', 26, 14, drawBarricade);
  make(scene, 'stop', 10, 28, drawStopSign);
  make(scene, 'fenceBack', 128, 92, (c) => drawFenceBack(c, 128, 92), null);
  make(scene, 'fenceFront', 128, 12, (c) => drawFenceFront(c, 128, 64), null);
  make(scene, 'sparkle', 3, 3, (c) => {
    rect(c, '#ffffff', 1, 0, 1, 3);
    rect(c, '#ffffff', 0, 1, 3, 1);
  }, null);
  make(scene, 'pin', 8, 8, (c) => {
    disc(c, '#ffffff', 4, 4, 3);
    disc(c, '#ff4a3a', 4, 4, 2);
  }, null);

  // suburban houses
  make(scene, 'house_red', 64, 58, (c) => drawHouse(c, 64, ROOF_RED, '#f2f0f4', '#c8c8d8', false));
  make(scene, 'house_orange', 64, 58, (c) => drawHouse(c, 64, ROOF_RED, '#f0a47c', '#c47a58', false));
  make(scene, 'house_blue', 80, 58, (c) => drawHouse(c, 80, ROOF_BLUE, '#f4d4a4', '#c8a678', true));
  void ROOF_ORANGE;

  // mid-rise blocks
  const gray: Partial<BoxCfg> = { hatch: '#8f8da2', edge: '#e6e6f0', doorCol: '#3a6fe0', awning: '#5a5878' };
  make(scene, 'bldg_tower', 80, 112, (c) =>
    drawBox(c, {
      ...gray,
      w: 80, roofH: 64, wallH: 48, ct: 0, cb: 0,
      roof: '#6f6d80', edge: '#2f57b8', trim: '#2f57b8', trimHi: '#5c86e0',
      wall: '#8a889e', wallDk: '#6a6880', cols: 2, rows: 2, doorW: 0,
      ac: [[26, 20], [10, 38]], winInset: 8,
    } as BoxCfg),
  );
  make(scene, 'bldg_green', 96, 100, (c) =>
    drawBox(c, {
      ...gray,
      w: 96, roofH: 62, wallH: 38, ct: 14, cb: 6,
      roof: '#6f6d80', trim: '#3f6a22', trimHi: '#6f9a44',
      wall: '#65953a', wallDk: '#3f6a22', cols: 3, rows: 1, doorW: 16,
      ac: [[16, 18], [56, 22]], winInset: 8,
    } as BoxCfg),
  );
  make(scene, 'bldg_brick', 64, 108, (c) =>
    drawBox(c, {
      ...gray,
      w: 64, roofH: 40, wallH: 68, ct: 0, cb: 0,
      roof: '#6f6d80', edge: '#f0f0f6', trim: '#f0f0f6', trimHi: '#ffffff',
      wall: '#a8483c', brick: '#732a2c', wallDk: '#7e2f30', cols: 2, rows: 3, doorW: 12,
      ac: [[22, 10]], winInset: 8,
    } as BoxCfg),
  );
  make(scene, 'bldg_big', 192, 222, (c) =>
    drawBox(c, {
      ...gray,
      w: 192, roofH: 90, wallH: 132, ct: 26, cb: 10, side: 14,
      roof: '#78768a', trim: '#b0404f', trimHi: '#d8697a',
      wall: '#f0f2f8', wallDk: '#c6cadc', sideCol: '#c9cddd', cols: 8, rows: 6, doorW: 24,
      ac: [[26, 26], [112, 26], [62, 50], [140, 50]], winInset: 6,
    } as BoxCfg),
  );

  // downtown
  make(scene, 'dt_shop', 144, 108, (c) => drawShop(c, 144));
  make(scene, 'dt_mall', 208, 116, (c) => drawMall(c, 208));
  make(scene, 'dt_ware', 176, 100, (c) => drawWarehouse(c, 176));
  make(scene, 'dt_apt', 128, 106, (c) => drawApartment(c, 128));

  // vehicles
  const seen = new Set<string>();
  for (const v of VEHICLES) {
    const id = `${v.kind}_${v.color}`;
    if (seen.has(id)) continue;
    seen.add(id);
    const w = v.kind === 'van' ? 46 : 38;
    const h = v.kind === 'van' ? 22 : 20;
    const col = CAR_COLORS[v.color];
    make(scene, vehicleKey(v.kind, v.color, 'h'), w, h, (c) => drawVehicleH(c, v.kind, col, w, h));
    make(scene, vehicleKey(v.kind, v.color, 'v'), h, w, (c) => {
      c.translate(h, 0);
      c.rotate(Math.PI / 2);
      drawVehicleH(c, v.kind, col, w, h);
    });
  }

  // people
  PEOPLE.forEach((p, i) => {
    (['down', 'up', 'side'] as const).forEach((dir) => {
      for (let f = 0; f < 3; f++) make(scene, `p${i}_${dir}_${f}`, 10, 16, (c) => drawPerson(c, p, dir, f, i === HERO));
    });
  });
}
