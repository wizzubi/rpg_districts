/**
 * World layout data: grid dimensions, road network, terrain classification
 * and static placement tables. Purely data – no Phaser dependency.
 */
export const TILE = 16;
export const COLS = 90;
export const ROWS = 64;
export const WORLD_W = COLS * TILE;
export const WORLD_H = ROWS * TILE;

/** Roads are 4 tiles wide (two 2-tile lanes). Values are the first row / column. */
export const ROAD = 4;
export const HROADS = [9, 29, 49];
export const VROADS = [11, 43, 75];

export const T = {
  GRASS: 0,
  ROAD: 1,
  SIDEWALK: 2,
  PLAZA: 3,
  PATH: 4,
  WATER: 5,
  COBBLE: 6,
} as const;

export const DOWNTOWN_X = 47; // tiles at or right of this column use the downtown palette

export const POND = { cx: 29, cy: 43.5, rx: 8, ry: 3.3 };

export const inHRoad = (y: number) => HROADS.some((h) => y >= h && y < h + ROAD);
export const inVRoad = (x: number) => VROADS.some((v) => x >= v && x < v + ROAD);
export const isRoadTile = (x: number, y: number) => inHRoad(y) || inVRoad(x);

export interface Crosswalk {
  x: number;
  y: number;
  w: number;
  h: number;
  /** direction the stripes run */
  bars: 'h' | 'v';
}

export const CROSSWALKS: Crosswalk[] = [];
export const INTERSECTIONS: { h: number; v: number }[] = [];
for (const h of HROADS) {
  for (const v of VROADS) {
    INTERSECTIONS.push({ h, v });
    CROSSWALKS.push({ x: v - 1, y: h, w: 1, h: ROAD, bars: 'h' });
    CROSSWALKS.push({ x: v + ROAD, y: h, w: 1, h: ROAD, bars: 'h' });
    CROSSWALKS.push({ x: v, y: h - 1, w: ROAD, h: 1, bars: 'v' });
    CROSSWALKS.push({ x: v, y: h + ROAD, w: ROAD, h: 1, bars: 'v' });
  }
}

/** Houses in the suburban rows. `ty` = bottom edge tile line, `tx` = left tile. */
export interface HouseSpec {
  key: string;
  tx: number;
  ty: number;
  w: number;
  doorTx: number;
  fenced?: boolean;
  pathTo: number; // last tile row the dirt path reaches
}
export const HOUSES: HouseSpec[] = [
  { key: 'house_red', tx: 19, ty: 6, w: 64, doorTx: 21, fenced: true, pathTo: 7 },
  { key: 'house_orange', tx: 32, ty: 6, w: 64, doorTx: 34, pathTo: 7 },
  { key: 'house_blue', tx: 37, ty: 6, w: 80, doorTx: 39, pathTo: 7 },
  { key: 'house_blue', tx: 18, ty: 38, w: 80, doorTx: 20, pathTo: 39 },
  { key: 'house_red', tx: 27, ty: 38, w: 64, doorTx: 29, pathTo: 39 },
  { key: 'house_orange', tx: 35, ty: 38, w: 64, doorTx: 37, pathTo: 39 },
];

export type Grid = Uint8Array[];

export function buildGrid(): Grid {
  const g: Grid = Array.from({ length: ROWS }, () => new Uint8Array(COLS));
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      if (isRoadTile(x, y)) {
        g[y][x] = T.ROAD;
        continue;
      }
      let near = false;
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) if (isRoadTile(x + dx, y + dy)) near = true;
      g[y][x] = near ? T.SIDEWALK : x >= 48 ? T.PLAZA : T.GRASS;
    }
  }

  const set = (x: number, y: number, t: number) => {
    if (x < 0 || y < 0 || x >= COLS || y >= ROWS) return;
    if (g[y][x] === T.GRASS) g[y][x] = t;
  };
  const hline = (x0: number, x1: number, y: number) => {
    for (let x = x0; x <= x1; x++) set(x, y, T.PATH);
  };
  const vline = (x: number, y0: number, y1: number) => {
    for (let y = y0; y <= y1; y++) set(x, y, T.PATH);
  };

  // winding forest trail (top-left)
  hline(0, 3, 3);
  vline(3, 3, 6);
  hline(3, 9, 6);
  // lower forest trail
  vline(5, 54, 58);
  hline(5, 8, 58);
  // trail south of the park
  vline(29, 54, 58);
  hline(26, 29, 58);

  // cobbled ridge (left block)
  for (let y = 19; y <= 20; y++) for (let x = 0; x <= 1; x++) set(x, y, T.COBBLE);
  for (let y = 21; y <= 24; y++) for (let x = 0; x <= 4; x++) set(x, y, T.COBBLE);

  // pond
  for (let y = 34; y < 48; y++) {
    for (let x = 16; x < 42; x++) {
      const nx = (x + 0.5 - POND.cx) / POND.rx;
      const ny = (y + 0.5 - POND.cy) / POND.ry;
      if (nx * nx + ny * ny <= 1) set(x, y, T.WATER);
    }
  }
  // promenade ring around the pond
  for (let y = 34; y < 48; y++) {
    for (let x = 16; x < 42; x++) {
      const nx = (x + 0.5 - POND.cx) / (POND.rx + 1.6);
      const ny = (y + 0.5 - POND.cy) / (POND.ry + 1.5);
      if (nx * nx + ny * ny <= 1) set(x, y, T.PATH);
    }
  }
  // house door paths
  for (const h of HOUSES) for (let y = h.ty; y <= h.pathTo; y++) set(h.doorTx, y, T.PATH);

  return g;
}

/** Friendly district names for the HUD. */
const ZONES: { name: string; x0: number; y0: number; x1: number; y1: number }[] = [
  { name: 'Maple Woods', x0: 0, y0: 0, x1: 10, y1: 64 },
  { name: 'Suburb Row', x0: 11, y0: 0, x1: 47, y1: 14 },
  { name: 'Skyline Apartments', x0: 11, y0: 14, x1: 47, y1: 29 },
  { name: 'Mirror Pond Park', x0: 11, y0: 33, x1: 47, y1: 49 },
  { name: 'Pinewalk Trail', x0: 11, y0: 53, x1: 47, y1: 64 },
  { name: 'Market Square', x0: 47, y0: 0, x1: 79, y1: 14 },
  { name: 'Civic Quarter', x0: 47, y0: 14, x1: 79, y1: 29 },
  { name: 'Grand Bazaar', x0: 47, y0: 33, x1: 79, y1: 49 },
  { name: 'Harbour Row', x0: 47, y0: 53, x1: 79, y1: 64 },
  { name: 'Parkside Lot', x0: 79, y0: 0, x1: 90, y1: 64 },
];

export function zoneAt(tx: number, ty: number, grid: Grid): string {
  const t = grid[Math.max(0, Math.min(ROWS - 1, ty))][Math.max(0, Math.min(COLS - 1, tx))];
  if (t === T.ROAD) {
    if (inHRoad(ty) && inVRoad(tx)) return 'Crossroads';
    return inHRoad(ty) ? 'Main Street' : tx < 47 ? 'Oak Avenue' : 'Tenth Avenue';
  }
  for (const z of ZONES) if (tx >= z.x0 && tx < z.x1 && ty >= z.y0 && ty < z.y1) return z.name;
  return 'Kenney City';
}

/** Minimap frame – shared by Phaser camera and the React overlay so they line up exactly. */
export function minimapRect(viewW: number, viewH: number) {
  const margin = viewW < 640 ? 10 : 16;
  const w = Math.round(Math.min(viewW < 640 ? 132 : 200, viewW * 0.36));
  const h = Math.round((w * WORLD_H) / WORLD_W);
  void viewH;
  return { x: viewW - w - margin, y: margin, w, h };
}
