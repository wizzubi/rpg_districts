import Phaser from 'phaser';
import { HERO, PAD, PEOPLE, VEHICLES, buildTextures, make, rng, sizeOf, vehicleKey } from './art';
import { paintGround } from './ground';
import {
  COLS,
  HOUSES,
  HROADS,
  INTERSECTIONS,
  ROWS,
  T,
  TILE,
  VROADS,
  WORLD_H,
  WORLD_W,
  buildGrid,
  minimapRect,
  zoneAt,
  type Grid,
} from './map';

type Rect = { x: number; y: number; w: number; h: number };
type LightState = 'green' | 'yellow' | 'red';
type Face = 'down' | 'up' | 'side';

interface Car {
  img: Phaser.GameObjects.Image;
  axis: 'h' | 'v';
  dir: 1 | -1;
  fixed: number;
  pos: number;
  v: number;
  base: number;
  len: number;
  lane: Car[];
}

interface Walker {
  img: Phaser.GameObjects.Image;
  shadow: Phaser.GameObjects.Image;
  pal: number;
  x: number;
  y: number;
  tx: number;
  ty: number;
  nx: number;
  ny: number;
  dx: number;
  dy: number;
  speed: number;
  pause: number;
  anim: number;
  jx: number;
  jy: number;
}

const ZOOM_STEPS = [1, 1.5, 2, 3, 4];
const WALK_FRAMES = [1, 0, 2, 0];

const CYCLE: { h: LightState; v: LightState; d: number }[] = [
  { h: 'green', v: 'red', d: 8 },
  { h: 'yellow', v: 'red', d: 1.6 },
  { h: 'red', v: 'red', d: 1.2 },
  { h: 'red', v: 'green', d: 8 },
  { h: 'red', v: 'yellow', d: 1.6 },
  { h: 'red', v: 'red', d: 1.2 },
];
const CYCLE_TOTAL = CYCLE.reduce((a, b) => a + b.d, 0);

export class CityScene extends Phaser.Scene {
  private grid!: Grid;
  private solids: Rect[] = [];
  private occ: boolean[][] = [];
  private rand = rng(20240607);

  private player!: Phaser.GameObjects.Image;
  private playerShadow!: Phaser.GameObjects.Image;
  private px = 0;
  private py = 0;
  private face: Face = 'down';
  private flip = false;
  private animT = 0;
  private target: { x: number; y: number } | null = null;
  private stuck = 0;
  private pad = { x: 0, y: 0 };
  private keys!: Record<string, Phaser.Input.Keyboard.Key>;

  private cars: Car[] = [];
  private walkers: Walker[] = [];
  private signals: { img: Phaser.GameObjects.Image; axis: 'h' | 'v'; state: LightState }[] = [];
  private sidewalkTiles: [number, number][] = [];

  private targetZoom = 2;
  private following = false;
  private intro = true;
  private dragging = false;
  private downAt = { x: 0, y: 0, t: 0 };
  private lastWheel = 0;

  private mini!: Phaser.Cameras.Scene2D.Camera;
  private miniPin!: Phaser.GameObjects.Image;
  private miniView!: Phaser.GameObjects.Graphics;

  private lastTile = '';
  private hudTimer = 0;

  constructor() {
    super('city');
  }

  /* ------------------------------------------------------------------ */
  create() {
    buildTextures(this);
    make(
      this,
      'pshadow',
      10,
      4,
      (c) => {
        c.fillStyle = 'rgba(10,20,40,0.28)';
        c.fillRect(2, 0, 6, 4);
        c.fillRect(1, 1, 8, 2);
      },
      null,
    );

    this.grid = buildGrid();
    paintGround(this, this.grid);
    this.add.image(0, 0, 'ground').setOrigin(0, 0).setDepth(-1000);
    this.occ = Array.from({ length: ROWS }, () => new Array<boolean>(COLS).fill(false));

    this.collectTerrain();
    this.layoutBuildings();
    this.layoutProps();
    this.scatterNature();
    this.spawnTraffic();
    this.spawnWalkers();
    this.spawnPlayer();
    this.setupCameras();
    this.setupInput();
    this.setupEvents();
    this.emitHud(true);
  }

  /* ------------------------------------------------------------------ */
  /* Placement helpers                                                   */
  /* ------------------------------------------------------------------ */
  private put(key: string, x: number, y: number, depth?: number) {
    const img = this.add.image(x - PAD, y + PAD, key).setOrigin(0, 1);
    img.setDepth(depth ?? y);
    return img;
  }

  private mark(x: number, y: number, w: number, h: number) {
    const x0 = Math.max(0, Math.floor(x / TILE));
    const x1 = Math.min(COLS - 1, Math.floor((x + w - 1) / TILE));
    const y0 = Math.max(0, Math.floor(y / TILE));
    const y1 = Math.min(ROWS - 1, Math.floor((y + h - 1) / TILE));
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) this.occ[ty][tx] = true;
  }

  private building(key: string, tx: number, ty: number) {
    const s = sizeOf(this, key);
    const x = tx * TILE;
    const y = ty * TILE;
    this.put(key, x, y);
    this.solids.push({ x, y: y - s.h + 6, w: s.w, h: s.h - 6 });
    this.mark(x, y - s.h, s.w, s.h);
  }

  private tree(key: string, cx: number, by: number) {
    const s = sizeOf(this, key);
    this.put(key, Math.round(cx - s.w / 2), by);
    this.solids.push({ x: cx - 4, y: by - 6, w: 8, h: 6 });
    const tx = Math.floor(cx / TILE);
    const ty = Math.floor((by - 1) / TILE);
    for (let yy = ty - 1; yy <= ty; yy++)
      for (let xx = tx - 1; xx <= tx + 1; xx++) if (yy >= 0 && xx >= 0 && xx < COLS) this.occ[yy][xx] = true;
  }

  private collectTerrain() {
    // merge horizontal runs of solid terrain (water / cobble cliff) into rects
    for (let y = 0; y < ROWS; y++) {
      let start = -1;
      let kind = -1;
      for (let x = 0; x <= COLS; x++) {
        const t = x < COLS ? this.grid[y][x] : -1;
        const solid = t === T.WATER || t === T.COBBLE;
        if (solid && start < 0) {
          start = x;
          kind = t;
        } else if ((!solid || t !== kind) && start >= 0) {
          this.solids.push({ x: start * TILE, y: y * TILE + (kind === T.WATER ? 2 : 0), w: (x - start) * TILE, h: TILE - (kind === T.WATER ? 2 : 0) });
          for (let xx = start; xx < x; xx++) this.occ[y][xx] = true;
          start = solid ? x : -1;
          kind = solid ? t : -1;
        }
        if (x < COLS && (t === T.SIDEWALK || t === T.PATH)) this.sidewalkTiles.push([x, y]);
      }
    }

    // pond sparkles
    for (let y = 0; y < ROWS; y++) {
      for (let x = 0; x < COLS; x++) {
        if (this.grid[y][x] !== T.WATER || this.rand() > 0.14) continue;
        const s = this.add
          .image(x * TILE + 2 + this.rand() * 11, y * TILE + 3 + this.rand() * 10, 'sparkle')
          .setDepth(-900)
          .setAlpha(0);
        this.tweens.add({
          targets: s,
          alpha: { from: 0, to: 0.95 },
          duration: 700 + this.rand() * 900,
          yoyo: true,
          repeat: -1,
          delay: this.rand() * 2400,
          repeatDelay: this.rand() * 1600,
        });
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* Static layout                                                       */
  /* ------------------------------------------------------------------ */
  private layoutBuildings() {
    for (const h of HOUSES) {
      this.building(h.key, h.tx, h.ty);
      if (h.fenced) {
        const fx = (h.doorTx - 4) * TILE;
        this.put('fenceBack', fx, 122, 5);
        this.put('fenceFront', fx, 120, 120);
        this.solids.push(
          { x: fx, y: 30, w: 128, h: 10 },
          { x: fx, y: 30, w: 3, h: 92 },
          { x: fx + 125, y: 30, w: 3, h: 92 },
          { x: fx, y: 110, w: 64, h: 10 },
          { x: fx + 80, y: 110, w: 48, h: 10 },
        );
        this.mark(fx, 30, 128, 92);
      }
    }

    const list: [string, number, number][] = [
      // skyline block (centre-west)
      ['bldg_green', 19, 28],
      ['bldg_tower', 23, 21],
      ['bldg_brick', 25, 28],
      ['bldg_big', 30, 28],
      // downtown
      ['dt_shop', 49, 7],
      ['dt_mall', 60, 7.5],
      ['dt_ware', 49, 28],
      ['dt_apt', 64, 28],
      ['bldg_tower', 56, 21],
      ['dt_apt', 52, 41],
      ['dt_ware', 62, 41],
      ['dt_shop', 49, 48],
      ['dt_mall', 60, 48],
      ['dt_apt', 50, 62],
      ['dt_mall', 58, 62],
      // east edge
      ['bldg_brick', 81, 7],
      ['bldg_tower', 85, 7.5],
      ['bldg_green', 82, 62],
    ];
    for (const [k, tx, ty] of list) this.building(k, tx, ty);
  }

  private layoutProps() {
    const cornerBlocked = (x: number) => VROADS.some((v) => x >= v - 4 && x <= v + 7);
    const cornerBlockedY = (y: number) => HROADS.some((h) => y >= h - 4 && y <= h + 7);

    // street lamps along the avenues
    for (const h of HROADS) {
      let i = 0;
      for (let x = 3; x < COLS - 1; x += 9) {
        if (cornerBlocked(x)) continue;
        const flip = i++ % 2 === 0;
        this.lamp(x * TILE + 8, (h - 1) * TILE + 15, flip);
        this.lamp((x + 4) * TILE + 8, (h + 4) * TILE + 15, !flip);
      }
    }
    for (const v of VROADS) {
      let i = 0;
      for (let y = 3; y < ROWS - 1; y += 9) {
        if (cornerBlockedY(y)) continue;
        i++;
        this.lamp((v - 1) * TILE + 8, y * TILE + 15, false);
        this.lamp((v + 4) * TILE + 8, (y + 4) * TILE + 15, true);
      }
      void i;
    }

    // traffic signals, bins & mailboxes on the corners
    for (const { h, v } of INTERSECTIONS) {
      const ns = this.put('tl_red', (v - 1) * TILE + 4, (h - 1) * TILE + 15);
      const ew = this.put('tl_red', (v + 4) * TILE + 4, (h + 4) * TILE + 15);
      this.signals.push({ img: ns, axis: 'v', state: 'red' }, { img: ew, axis: 'h', state: 'red' });
      this.put('trash', (v + 4) * TILE + 2, (h - 1) * TILE + 15);
      this.put('mailbox', (v - 1) * TILE + 2, (h + 4) * TILE + 15);
    }

    // benches
    const bench = (x: number, y: number) => {
      this.put('bench', x, y);
      this.solids.push({ x, y: y - 10, w: 32, h: 10 });
      this.mark(x, y - 12, 32, 12);
    };
    bench(25 * TILE, 6 * TILE + 12);
    bench(17 * TILE, 44 * TILE);
    bench(40 * TILE, 44 * TILE);
    bench(52 * TILE, 37 * TILE);
    bench(70 * TILE, 37 * TILE);
    bench(54 * TILE, 18 * TILE);
    bench(72 * TILE, 18 * TILE);

    // roadworks on the plaza edge
    this.put('barricade', 66 * TILE, 33 * TILE + 13);
    this.put('barricade', 69 * TILE, 33 * TILE + 13);
    for (const x of [1056, 1090, 1120, 1160]) this.put('cone', x, 33 * TILE + 14);

    // plaza planters
    const cones: [number, number][] = [
      [772, 112], [944, 112], [1178, 112],
      [772, 446], [992, 446], [1178, 446],
      [772, 766], [944, 766], [1178, 766],
      [772, 990], [1150, 990],
      [1316, 446], [1404, 446], [1316, 766], [1404, 766], [1316, 880],
    ];
    for (const [cx, by] of cones) {
      const s = sizeOf(this, 'coneTree');
      this.put('coneTree', cx - s.w / 2, by);
      this.solids.push({ x: cx - 9, y: by - 10, w: 18, h: 10 });
      this.mark(cx - 12, by - 20, 24, 20);
    }
  }

  private lamp(cx: number, by: number, flip: boolean) {
    const img = this.put('lamp', cx - (flip ? 11 : 4), by);
    img.setFlipX(flip);
  }

  private scatterNature() {
    const r = this.rand;
    const g = this.grid;

    // palms
    const palms: [number, number][] = [
      [320, 322], [20 * 16 + 8, 55 * 16], [25 * 16 + 8, 55 * 16], [33 * 16 + 8, 55 * 16], [38 * 16 + 8, 55 * 16],
      [2 * 16 + 8, 55 * 16], [8 * 16 + 4, 30 * 16 + 6],
    ];
    for (const [cx, by] of palms) this.tree('palm', cx, by);

    const zones = [
      { x0: 0, y0: 0, x1: 9, y1: 7, n: 10 },
      { x0: 0, y0: 14, x1: 9, y1: 27, n: 15 },
      { x0: 0, y0: 34, x1: 9, y1: 47, n: 15 },
      { x0: 0, y0: 54, x1: 9, y1: 63, n: 9 },
      { x0: 16, y0: 54, x1: 41, y1: 63, n: 18 },
      { x0: 16, y0: 34, x1: 41, y1: 47, n: 13 },
      { x0: 26, y0: 0, x1: 31, y1: 7, n: 1 },
      { x0: 16, y0: 14, x1: 22, y1: 19, n: 2 },
    ];
    const free = (tx: number, ty: number) => {
      for (let yy = ty - 1; yy <= ty; yy++)
        for (let xx = tx - 1; xx <= tx + 1; xx++) {
          if (xx < 0 || yy < 0 || xx >= COLS || yy >= ROWS) return false;
          if (this.occ[yy][xx]) return false;
        }
      return [tx - 1, tx, tx + 1].every((xx) => g[ty][xx] === T.GRASS);
    };
    for (const z of zones) {
      let placed = 0;
      for (let i = 0; i < z.n * 40 && placed < z.n; i++) {
        const tx = z.x0 + Math.floor(r() * (z.x1 - z.x0 + 1));
        const ty = z.y0 + 1 + Math.floor(r() * (z.y1 - z.y0));
        if (!free(tx, ty)) continue;
        const roll = r();
        const key = roll < 0.4 ? (r() < 0.5 ? 'treeBig' : 'treeBig2') : roll < 0.75 ? 'treeMid' : 'treeSmall';
        this.tree(key, tx * TILE + 8 + Math.round((r() - 0.5) * 6), (ty + 1) * TILE - 2);
        placed++;
      }
    }

    // a big tree beside the suburban fence, as in the reference
    this.tree('treeBig', 29 * TILE + 4, 7 * TILE + 4);

    // bushes & rocks
    for (let i = 0; i < 220; i++) {
      const tx = Math.floor(r() * 48);
      const ty = Math.floor(r() * ROWS);
      if (g[ty][tx] !== T.GRASS || this.occ[ty][tx]) continue;
      const bush = r() < 0.4;
      this.put(bush ? 'bush' : 'rock', tx * TILE + 2 + r() * 6, ty * TILE + 12 + r() * 3);
      this.occ[ty][tx] = true;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Traffic                                                             */
  /* ------------------------------------------------------------------ */
  private spawnTraffic() {
    const r = this.rand;
    const add = (axis: 'h' | 'v', dir: 1 | -1, fixed: number, count: number) => {
      const span = axis === 'h' ? WORLD_W : WORLD_H;
      const lane: Car[] = [];
      for (let i = 0; i < count; i++) {
        let pos = ((i + 0.15 + r() * 0.5) * span) / count;
        const inJunction = (p: number) =>
          axis === 'h'
            ? VROADS.some((v) => p > (v - 2) * TILE && p < (v + 6) * TILE)
            : HROADS.some((h) => p > (h - 2) * TILE && p < (h + 6) * TILE);
        for (let k = 0; k < 12 && inJunction(pos); k++) pos += 40;
        const veh = VEHICLES[Math.floor(r() * VEHICLES.length)];
        const key = vehicleKey(veh.kind, veh.color, axis);
        const s = sizeOf(this, key);
        const img = this.add.image(0, 0, key).setOrigin(0.5, 0.5);
        if (dir < 0) axis === 'h' ? img.setFlipX(true) : img.setFlipY(true);
        lane.push({
          img,
          axis,
          dir,
          fixed,
          pos,
          v: 0,
          base: (veh.kind === 'van' ? 34 : 40) + r() * 14,
          len: axis === 'h' ? s.w : s.h,
          lane,
        });
      }
      this.cars.push(...lane);
    };
    for (const h of HROADS) {
      add('h', -1, h * TILE + 16, 4);
      add('h', 1, h * TILE + 48, 4);
    }
    for (const v of VROADS) {
      add('v', 1, v * TILE + 16, 3);
      add('v', -1, v * TILE + 48, 3);
    }
    this.updateCars(0);
  }

  private lightState(axis: 'h' | 'v', t: number): LightState {
    let m = t % CYCLE_TOTAL;
    for (const p of CYCLE) {
      if (m < p.d) return p[axis];
      m -= p.d;
    }
    return 'red';
  }

  private updateLights(t: number) {
    for (const l of this.signals) {
      const s = this.lightState(l.axis, t);
      if (s !== l.state) {
        l.state = s;
        l.img.setTexture(`tl_${s}`);
      }
    }
  }

  private updateCars(dt: number) {
    const t = this.time.now / 1000;
    const st = { h: this.lightState('h', t), v: this.lightState('v', t) };
    for (const c of this.cars) {
      const span = c.axis === 'h' ? WORLD_W : WORLD_H;
      const front = c.pos + (c.dir * c.len) / 2;
      let vmax = c.base;

      // signals
      const lines =
        c.axis === 'h'
          ? VROADS.map((v) => (c.dir > 0 ? (v - 1) * TILE - 3 : (v + 5) * TILE + 3))
          : HROADS.map((h) => (c.dir > 0 ? (h - 1) * TILE - 3 : (h + 5) * TILE + 3));
      for (const line of lines) {
        const dist = (line - front) * c.dir;
        if (dist < -1.5 || dist > 40) continue;
        const s = st[c.axis];
        if (s === 'red' || (s === 'yellow' && dist > 10)) vmax = Math.min(vmax, Math.max(0, dist - 2) * 2.4);
      }
      // following distance
      for (const o of c.lane) {
        if (o === c) continue;
        const gap = (o.pos - c.pos) * c.dir - (o.len + c.len) / 2;
        if (gap > -2 && gap < 34) vmax = Math.min(vmax, Math.max(0, gap - 5) * 2.4);
      }

      if (c.v > vmax) c.v = Math.max(vmax, c.v - 150 * dt);
      else c.v = Math.min(vmax, c.v + 55 * dt);

      c.pos += c.dir * c.v * dt;
      if (c.dir > 0 && c.pos > span + 60) c.pos = -60;
      if (c.dir < 0 && c.pos < -60) c.pos = span + 60;

      if (c.axis === 'h') c.img.setPosition(Math.round(c.pos), c.fixed);
      else c.img.setPosition(c.fixed, Math.round(c.pos));
      c.img.setDepth(c.axis === 'h' ? c.fixed + 8 : c.pos + c.len / 2);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Pedestrians                                                         */
  /* ------------------------------------------------------------------ */
  private walkable(tx: number, ty: number) {
    if (tx < 0 || ty < 0 || tx >= COLS || ty >= ROWS) return false;
    const t = this.grid[ty][tx];
    return t === T.SIDEWALK || t === T.PATH;
  }

  private spawnWalkers() {
    const r = this.rand;
    for (let i = 0; i < 38; i++) {
      const [tx, ty] = this.sidewalkTiles[Math.floor(r() * this.sidewalkTiles.length)];
      const pal = i % (PEOPLE.length - 1);
      const jx = Math.round((r() - 0.5) * 6);
      const jy = Math.round((r() - 0.5) * 6);
      const shadow = this.add.image(0, 0, 'pshadow').setOrigin(0.5, 0.5);
      const img = this.add.image(0, 0, `p${pal}_down_0`).setOrigin(0.5, 1);
      const w: Walker = {
        img,
        shadow,
        pal,
        x: tx * TILE + 8 + jx,
        y: ty * TILE + 12 + jy,
        tx,
        ty,
        nx: tx,
        ny: ty,
        dx: 0,
        dy: 0,
        speed: 17 + r() * 9,
        pause: r() * 2,
        anim: r() * 4,
        jx,
        jy,
      };
      this.pickNext(w);
      this.walkers.push(w);
    }
    this.updateWalkers(0);
  }

  private pickNext(w: Walker) {
    const dirs: [number, number][] = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    const opts = dirs.filter(([dx, dy]) => this.walkable(w.tx + dx, w.ty + dy));
    if (!opts.length) {
      w.dx = 0;
      w.dy = 0;
      return;
    }
    const straight = opts.find(([dx, dy]) => dx === w.dx && dy === w.dy);
    const nonBack = opts.filter(([dx, dy]) => !(dx === -w.dx && dy === -w.dy));
    let choice: [number, number];
    if (straight && this.rand() < 0.78) choice = straight;
    else if (nonBack.length) choice = nonBack[Math.floor(this.rand() * nonBack.length)];
    else choice = opts[Math.floor(this.rand() * opts.length)];
    w.dx = choice[0];
    w.dy = choice[1];
    w.nx = w.tx + w.dx;
    w.ny = w.ty + w.dy;
    if (this.rand() < 0.08) w.pause = 0.6 + this.rand() * 2;
  }

  private updateWalkers(dt: number) {
    for (const w of this.walkers) {
      let moving = false;
      if (w.pause > 0) {
        w.pause -= dt;
      } else if (w.dx !== 0 || w.dy !== 0) {
        const gx = w.nx * TILE + 8 + w.jx;
        const gy = w.ny * TILE + 12 + w.jy;
        const ddx = gx - w.x;
        const ddy = gy - w.y;
        const d = Math.hypot(ddx, ddy);
        const step = w.speed * dt;
        if (d <= step) {
          w.x = gx;
          w.y = gy;
          w.tx = w.nx;
          w.ty = w.ny;
          this.pickNext(w);
        } else {
          w.x += (ddx / d) * step;
          w.y += (ddy / d) * step;
        }
        moving = true;
      } else {
        this.pickNext(w);
      }

      let face: Face = 'down';
      if (w.dx !== 0) face = 'side';
      else if (w.dy < 0) face = 'up';
      if (moving) w.anim += dt;
      const f = moving ? WALK_FRAMES[Math.floor(w.anim / 0.16) % 4] : 0;
      w.img.setTexture(`p${w.pal}_${face}_${f}`);
      w.img.setFlipX(face === 'side' && w.dx < 0);
      const ix = Math.round(w.x);
      const iy = Math.round(w.y);
      w.img.setPosition(ix, iy + PAD);
      w.img.setDepth(iy);
      w.shadow.setPosition(ix, iy - 1).setDepth(iy - 0.5);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Player                                                              */
  /* ------------------------------------------------------------------ */
  private spawnPlayer() {
    this.px = 17 * TILE + 8;
    this.py = 13 * TILE + 12;
    this.playerShadow = this.add.image(this.px, this.py - 1, 'pshadow').setDepth(this.py - 0.5);
    this.player = this.add.image(this.px, this.py + PAD, `p${HERO}_down_0`).setOrigin(0.5, 1).setDepth(this.py);
  }

  private blocked(x: number, y: number) {
    if (x < 6 || x > WORLD_W - 6 || y < 14 || y > WORLD_H - 2) return true;
    const l = x - 3;
    const r = x + 3;
    const t = y - 4;
    for (const s of this.solids) {
      if (l < s.x + s.w && r > s.x && t < s.y + s.h && y > s.y) return true;
    }
    return false;
  }

  private updatePlayer(dt: number) {
    const k = this.keys;
    let vx = 0;
    let vy = 0;
    if (k.LEFT.isDown || k.A.isDown) vx -= 1;
    if (k.RIGHT.isDown || k.D.isDown) vx += 1;
    if (k.UP.isDown || k.W.isDown) vy -= 1;
    if (k.DOWN.isDown || k.S.isDown) vy += 1;
    vx += this.pad.x;
    vy += this.pad.y;

    if (vx || vy) {
      this.target = null;
      this.resumeFollow();
    } else if (this.target) {
      const dx = this.target.x - this.px;
      const dy = this.target.y - this.py;
      const d = Math.hypot(dx, dy);
      if (d < 2) this.target = null;
      else {
        vx = dx / d;
        vy = dy / d;
      }
    }
    const len = Math.hypot(vx, vy);
    if (len > 1) {
      vx /= len;
      vy /= len;
    }
    const run = k.SHIFT.isDown;
    const sp = (run ? 118 : 74) * dt;
    const ox = this.px;
    const oy = this.py;
    if (vx && !this.blocked(this.px + vx * sp, this.py)) this.px += vx * sp;
    if (vy && !this.blocked(this.px, this.py + vy * sp)) this.py += vy * sp;
    const moved = Math.hypot(this.px - ox, this.py - oy);

    if (this.target) {
      if (moved < sp * 0.25) this.stuck += dt;
      else this.stuck = 0;
      if (this.stuck > 0.3) {
        this.target = null;
        this.stuck = 0;
      }
    }

    if (Math.abs(vx) > 0.01 || Math.abs(vy) > 0.01) {
      if (Math.abs(vx) > Math.abs(vy)) {
        this.face = 'side';
        this.flip = vx < 0;
      } else this.face = vy > 0 ? 'down' : 'up';
    }
    if (moved > 0.01) this.animT += dt * (run ? 1.5 : 1);
    const f = moved > 0.01 ? WALK_FRAMES[Math.floor(this.animT / 0.13) % 4] : 0;
    this.player.setTexture(`p${HERO}_${this.face}_${f}`).setFlipX(this.face === 'side' && this.flip);
    const ix = Math.round(this.px);
    const iy = Math.round(this.py);
    this.player.setPosition(ix, iy + PAD).setDepth(iy);
    this.playerShadow.setPosition(ix, iy - 1).setDepth(iy - 0.5);
  }

  /* ------------------------------------------------------------------ */
  /* Cameras                                                             */
  /* ------------------------------------------------------------------ */
  private setupCameras() {
    const cam = this.cameras.main;
    cam.setBounds(0, 0, WORLD_W, WORLD_H);
    cam.setBackgroundColor('#0f3b33');
    this.targetZoom = this.scale.width >= 640 ? 2 : 1.5;

    // minimap
    const m = minimapRect(this.scale.width, this.scale.height);
    this.mini = this.cameras.add(m.x, m.y, m.w, m.h);
    this.mini.setBackgroundColor('#0f3b33');
    this.mini.setZoom(m.w / WORLD_W);
    this.mini.centerOn(WORLD_W / 2, WORLD_H / 2);
    this.miniPin = this.add.image(this.px, this.py, 'pin').setDepth(99999);
    this.miniView = this.add.graphics().setDepth(99998);
    cam.ignore([this.miniPin, this.miniView]);

    this.scale.on('resize', this.onResize, this);
    this.events.once('shutdown', () => this.scale.off('resize', this.onResize, this));

    // cinematic intro: pull in from the overview to the hero
    const startZoom = Math.max(0.6, Math.min(this.scale.width / WORLD_W, this.scale.height / WORLD_H, 1));
    cam.setZoom(startZoom);
    cam.centerOn(WORLD_W / 2, WORLD_H / 2);
    cam.fadeIn(900, 15, 59, 51);
    const from = { x: WORLD_W / 2, y: WORLD_H / 2, z: startZoom };
    this.tweens.addCounter({
      from: 0,
      to: 1,
      duration: 2400,
      delay: 500,
      ease: 'Cubic.easeInOut',
      onUpdate: (tw) => {
        const p = tw.getValue() ?? 0;
        cam.setZoom(from.z + (this.targetZoom - from.z) * p);
        cam.centerOn(from.x + (this.px - from.x) * p, from.y + (this.py - from.y) * p);
      },
      onComplete: () => {
        this.intro = false;
        cam.startFollow(this.player, true, 0.12, 0.12);
        this.following = true;
      },
    });
  }

  private onResize = () => {
    const m = minimapRect(this.scale.width, this.scale.height);
    this.mini.setViewport(m.x, m.y, m.w, m.h);
    this.mini.setZoom(m.w / WORLD_W);
    this.mini.centerOn(WORLD_W / 2, WORLD_H / 2);
  };

  private resumeFollow() {
    if (this.intro || this.following) return;
    this.cameras.main.startFollow(this.player, true, 0.12, 0.12);
    this.following = true;
  }

  private inMini(x: number, y: number) {
    const v = this.mini;
    return x >= v.x && x <= v.x + v.width && y >= v.y && y <= v.y + v.height;
  }

  private setupInput() {
    const kb = this.input.keyboard;
    if (kb) this.keys = kb.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,SHIFT') as Record<string, Phaser.Input.Keyboard.Key>;
    else this.keys = {} as Record<string, Phaser.Input.Keyboard.Key>;

    this.input.addPointer(1);
    this.input.on('pointerdown', (p: Phaser.Input.Pointer) => {
      this.downAt = { x: p.x, y: p.y, t: this.time.now };
      this.dragging = false;
    });
    this.input.on('pointermove', (p: Phaser.Input.Pointer) => {
      if (!p.isDown || this.intro || this.inMini(this.downAt.x, this.downAt.y)) return;
      if (!this.dragging && Math.hypot(p.x - this.downAt.x, p.y - this.downAt.y) > 8) {
        this.dragging = true;
        this.cameras.main.stopFollow();
        this.following = false;
      }
      if (this.dragging) {
        const cam = this.cameras.main;
        cam.scrollX -= (p.x - p.prevPosition.x) / cam.zoom;
        cam.scrollY -= (p.y - p.prevPosition.y) / cam.zoom;
      }
    });
    this.input.on('pointerup', (p: Phaser.Input.Pointer) => {
      if (this.intro) return;
      if (this.inMini(this.downAt.x, this.downAt.y)) {
        const v = this.mini;
        const wx = ((p.x - v.x) / v.width) * WORLD_W;
        const wy = ((p.y - v.y) / v.height) * WORLD_H;
        this.cameras.main.stopFollow();
        this.following = false;
        this.tweens.add({
          targets: this.cameras.main,
          scrollX: wx - this.cameras.main.width / 2,
          scrollY: wy - this.cameras.main.height / 2,
          duration: 450,
          ease: 'Cubic.easeOut',
        });
        return;
      }
      if (this.dragging) {
        this.dragging = false;
        return;
      }
      if (this.time.now - this.downAt.t > 450) return;
      const wp = this.cameras.main.getWorldPoint(p.x, p.y);
      this.target = { x: Phaser.Math.Clamp(wp.x, 8, WORLD_W - 8), y: Phaser.Math.Clamp(wp.y, 20, WORLD_H - 4) };
      this.resumeFollow();
      this.ping(this.target.x, this.target.y);
    });
    this.input.on('wheel', (_p: unknown, _o: unknown, _dx: number, dy: number) => {
      if (this.time.now - this.lastWheel < 120) return;
      this.lastWheel = this.time.now;
      this.stepZoom(dy < 0 ? 1 : -1);
    });
  }

  private ping(x: number, y: number) {
    const g = this.add.graphics().setDepth(99990);
    g.lineStyle(1, 0xffffff, 1);
    g.strokeCircle(0, 0, 3);
    g.setPosition(x, y);
    this.cameras.main.ignore([]);
    this.mini.ignore(g);
    this.tweens.add({
      targets: g,
      scale: 3,
      alpha: 0,
      duration: 520,
      ease: 'Cubic.easeOut',
      onComplete: () => g.destroy(),
    });
  }

  private stepZoom(dir: number) {
    let idx = ZOOM_STEPS.findIndex((z) => z >= this.targetZoom - 0.01);
    if (idx < 0) idx = ZOOM_STEPS.length - 1;
    idx = Phaser.Math.Clamp(idx + dir, 0, ZOOM_STEPS.length - 1);
    this.targetZoom = ZOOM_STEPS[idx];
    this.emitHud(true);
  }

  private setupEvents() {
    const ev = this.game.events;
    const onZoom = (d: number) => this.stepZoom(d);
    const onLocate = () => {
      this.resumeFollow();
      if (!this.following && !this.intro) {
        this.cameras.main.startFollow(this.player, true, 0.12, 0.12);
        this.following = true;
      }
    };
    const onPad = (v: { x: number; y: number }) => {
      this.pad = v;
    };
    ev.on('cmd:zoom', onZoom);
    ev.on('cmd:locate', onLocate);
    ev.on('cmd:pad', onPad);
    this.events.once('shutdown', () => {
      ev.off('cmd:zoom', onZoom);
      ev.off('cmd:locate', onLocate);
      ev.off('cmd:pad', onPad);
    });
  }

  private emitHud(force = false) {
    const tx = Math.floor(this.px / TILE);
    const ty = Math.floor(this.py / TILE);
    const zone = zoneAt(tx, ty, this.grid);
    const sig = `${zone}|${tx}|${ty}|${this.targetZoom}`;
    if (!force && sig === this.lastTile) return;
    this.lastTile = sig;
    this.game.events.emit('hud', { zone, tx, ty, zoom: this.targetZoom });
  }

  /* ------------------------------------------------------------------ */
  update(_t: number, delta: number) {
    const dt = Math.min(delta, 50) / 1000;
    this.updateLights(this.time.now / 1000);
    this.updatePlayer(dt);
    this.updateCars(dt);
    this.updateWalkers(dt);

    const cam = this.cameras.main;
    if (!this.intro) cam.setZoom(cam.zoom + (this.targetZoom - cam.zoom) * Math.min(1, dt * 9));

    // minimap overlays
    this.miniPin.setPosition(this.px, this.py).setScale(1 / this.mini.zoom);
    this.miniView.clear();
    this.miniView.lineStyle(2 / this.mini.zoom, 0xffffff, 0.9);
    const v = cam.worldView;
    this.miniView.strokeRect(v.x, v.y, v.width, v.height);

    this.hudTimer += dt;
    if (this.hudTimer > 0.25) {
      this.hudTimer = 0;
      this.emitHud();
    }
  }
}
