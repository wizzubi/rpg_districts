import Phaser from 'phaser';
import { CityScene } from './CityScene';

export function createGame(parent: HTMLElement) {
  return new Phaser.Game({
    type: Phaser.AUTO,
    parent,
    backgroundColor: '#0f3b33',
    width: parent.clientWidth || window.innerWidth,
    height: parent.clientHeight || window.innerHeight,
    scale: { mode: Phaser.Scale.RESIZE, autoCenter: Phaser.Scale.NO_CENTER },
    render: { pixelArt: true, antialias: false, roundPixels: true },
    input: { keyboard: true, touch: true },
    disableContextMenu: true,
    banner: false,
    scene: [CityScene],
  });
}
